package com.amir.netscout

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.RemoteViews
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Collections

class NetWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) appWidgetManager.updateAppWidget(id, render(context))
    }

    companion object {
        fun render(ctx: Context): RemoteViews {
            Store.init(ctx)
            val v = RemoteViews(ctx.packageName, R.layout.widget)
            v.setTextViewText(R.id.w_count, Store.lastCount.toString() + " " + t("devices", "جهاز"))
            v.setTextViewText(
                R.id.w_speed,
                if (Store.lastDown >= 0) String.format(java.util.Locale.US, "↓ %.1f Mbps", Store.lastDown) else t("Tap to scan", "اضغط للفحص")
            )
            val pi = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            v.setOnClickPendingIntent(R.id.w_root, pi)
            return v
        }

        fun updateAll(ctx: Context) {
            val awm = AppWidgetManager.getInstance(ctx)
            val ids = awm.getAppWidgetIds(ComponentName(ctx, NetWidget::class.java))
            for (id in ids) awm.updateAppWidget(id, render(ctx))
        }
    }
}

/** Quick Settings tile: tap to scan the network from the notification shade. */
class ScanTile : TileService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onStartListening() {
        Store.init(this)
        show(Store.lastCount.toString() + " " + t("devices", "جهاز"))
    }

    private fun show(text: String) {
        val tile = qsTile ?: return
        tile.state = Tile.STATE_ACTIVE
        tile.label = "NetScout"
        if (android.os.Build.VERSION.SDK_INT >= 29) tile.subtitle = text
        tile.updateTile()
    }

    override fun onClick() {
        Store.init(this)
        val info = Net.info(this)
        if (info == null) { show(t("No Wi-Fi", "لا واي فاي")); return }
        show(t("Scanning…", "جارٍ الفحص…"))
        scope.launch {
            val found = Collections.synchronizedList(mutableListOf<Device>())
            Net.scan(applicationContext, info) { found.add(it) }
            val list = found.toList()
            Store.setLast(list.size)
            val fresh = Store.record(list)
            NetWidget.updateAll(applicationContext)
            show(list.size.toString() + " " + t("devices", "جهاز"))
            if (fresh.isNotEmpty()) Monitor.notifyFresh(applicationContext, fresh)
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
