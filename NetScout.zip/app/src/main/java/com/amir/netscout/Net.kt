package com.amir.netscout

import android.content.Context
import android.net.ConnectivityManager
import android.net.wifi.WifiManager
import android.os.Build
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.*

data class Device(
    val ip: String, val host: String, val mac: String, val pingMs: Long,
    val isSelf: Boolean = false, val isGateway: Boolean = false,
    val kind: String = "unknown", val info: String = ""
)

data class NetInfo(
    val ssid: String, val ip: String, val gateway: String, val dns: String,
    val speedMbps: Int, val rssi: Int, val freqMhz: Int, val prefix: Int
)

object Net {
    val ports = linkedMapOf(
        21 to "FTP", 22 to "SSH", 23 to "Telnet", 53 to "DNS", 80 to "HTTP", 139 to "NetBIOS",
        443 to "HTTPS", 445 to "SMB", 554 to "RTSP", 631 to "IPP", 3389 to "RDP",
        7547 to "TR-069", 8080 to "HTTP-alt", 8443 to "HTTPS-alt", 9100 to "Printer", 62078 to "iOS sync"
    )

    @Suppress("DEPRECATION")
    fun info(ctx: Context): NetInfo? {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return null
        val lp = cm.getLinkProperties(net) ?: return null
        val la = lp.linkAddresses.firstOrNull { it.address is Inet4Address } ?: return null
        val gw = lp.routes.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }
            ?.gateway?.hostAddress ?: ""
        val dns = lp.dnsServers.joinToString { it.hostAddress ?: "" }
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val wi = wm.connectionInfo
        val ssid = wi?.ssid?.trim('"')?.takeIf { it != "<unknown ssid>" } ?: "—"
        return NetInfo(
            ssid, la.address.hostAddress ?: "", gw, dns,
            wi?.linkSpeed ?: 0, wi?.rssi ?: 0, wi?.frequency ?: 0, la.prefixLength
        )
    }

    fun ipToLong(ip: String): Long =
        ip.split(".").fold(0L) { a, s -> a * 256 + (s.toLongOrNull() ?: 0L) }

    fun longToIp(v: Long): String =
        "${(v shr 24) and 255}.${(v shr 16) and 255}.${(v shr 8) and 255}.${v and 255}"

    fun broadcast(i: NetInfo): String {
        val mask = (0xFFFFFFFFL shl (32 - i.prefix)) and 0xFFFFFFFFL
        return longToIp((ipToLong(i.ip) and mask) or (mask.inv() and 0xFFFFFFFFL))
    }

    /** Returns round-trip ms if host is alive, -1 otherwise. */
    fun probe(ip: String): Long {
        val a = InetAddress.getByName(ip)
        val s = System.currentTimeMillis()
        try {
            if (a.isReachable(250)) return System.currentTimeMillis() - s
        } catch (e: Exception) { }
        for (p in intArrayOf(80, 443, 445, 22, 53, 8080, 62078)) {
            val t = System.currentTimeMillis()
            try {
                Socket().use { it.connect(InetSocketAddress(a, p), 150) }
                return System.currentTimeMillis() - t
            } catch (e: ConnectException) {
                if (e.message?.contains("refused", true) == true) return System.currentTimeMillis() - t
            } catch (e: Exception) { }
        }
        return -1
    }

    private fun arp(): Map<String, String> = try {
        File("/proc/net/arp").readLines().drop(1).mapNotNull { l ->
            val p = l.trim().split(Regex("\\s+"))
            if (p.size >= 4 && p[3] != "00:00:00:00:00:00") p[0] to p[3] else null
        }.toMap()
    } catch (e: Exception) { emptyMap() }

    private suspend fun hostName(ip: String): String = withTimeoutOrNull(1200) {
        CoroutineScope(Dispatchers.IO).async {
            try {
                val h = InetAddress.getByName(ip).canonicalHostName
                if (h == ip) "" else h
            } catch (e: Exception) { "" }
        }.await()
    } ?: ""

    // ---- extra discovery: SSDP/UPnP, NetBIOS, mDNS ----
    fun ssdp(ctx: Context, ms: Int = 2000): Map<String, String> {
        val out = HashMap<String, String>()
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val lock = try { wm.createMulticastLock("netscout").also { it.acquire() } } catch (e: Exception) { null }
        try {
            DatagramSocket().use { s ->
                s.soTimeout = 300
                val msg = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 1\r\nST: ssdp:all\r\n\r\n".toByteArray()
                s.send(DatagramPacket(msg, msg.size, InetAddress.getByName("239.255.255.250"), 1900))
                val end = System.currentTimeMillis() + ms
                val buf = ByteArray(2048)
                while (System.currentTimeMillis() < end) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        s.receive(p)
                        val txt = String(p.data, 0, p.length)
                        val server = Regex("(?im)^server:\\s*(.+)$").find(txt)?.groupValues?.get(1)?.trim() ?: "UPnP"
                        out.putIfAbsent(p.address.hostAddress ?: "", server)
                    } catch (e: SocketTimeoutException) { }
                }
            }
        } catch (e: Exception) { }
        try { lock?.release() } catch (e: Exception) { }
        return out
    }

    fun netbios(ip: String): String {
        try {
            DatagramSocket().use { s ->
                s.soTimeout = 400
                val q = byteArrayOf(0x82.toByte(), 0x28, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0x20) +
                    "CKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA".toByteArray() + byteArrayOf(0, 0, 0x21, 0, 1)
                s.send(DatagramPacket(q, q.size, InetAddress.getByName(ip), 137))
                val b = ByteArray(512)
                val p = DatagramPacket(b, b.size)
                s.receive(p)
                if (p.length > 72) return String(b, 57, 15).trim()
            }
        } catch (e: Exception) { }
        return ""
    }

    private fun dnsName(b: ByteArray, start: Int): Pair<String, Int> {
        val sb = StringBuilder()
        var pos = start
        var end = -1
        var jumps = 0
        while (pos < b.size && jumps < 20) {
            val l = b[pos].toInt() and 255
            if (l == 0) { if (end < 0) end = pos + 1; break }
            if ((l and 0xC0) == 0xC0) {
                if (end < 0) end = pos + 2
                pos = ((l and 0x3F) shl 8) or (b[pos + 1].toInt() and 255)
                jumps++
                continue
            }
            sb.append(String(b, pos + 1, l)).append('.')
            pos += l + 1
        }
        return sb.toString().trimEnd('.') to (if (end < 0) pos else end)
    }

    fun mdnsName(ip: String): String {
        try {
            val bo = ByteArrayOutputStream()
            bo.write(byteArrayOf(0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0))
            for (l in ip.split(".").reversed() + listOf("in-addr", "arpa")) {
                bo.write(l.length); bo.write(l.toByteArray())
            }
            bo.write(0)
            bo.write(byteArrayOf(0, 12, 0, 1))
            val q = bo.toByteArray()
            DatagramSocket().use { s ->
                s.soTimeout = 500
                s.send(DatagramPacket(q, q.size, InetAddress.getByName(ip), 5353))
                val b = ByteArray(1024)
                val p = DatagramPacket(b, b.size)
                s.receive(p)
                if (p.length < 13) return ""
                val qd = ((b[4].toInt() and 255) shl 8) or (b[5].toInt() and 255)
                val an = ((b[6].toInt() and 255) shl 8) or (b[7].toInt() and 255)
                if (an == 0) return ""
                var pos = 12
                repeat(qd) { pos = dnsName(b, pos).second + 4 }
                pos = dnsName(b, pos).second + 10
                return dnsName(b, pos).first.removeSuffix(".local")
            }
        } catch (e: Exception) { }
        return ""
    }

    fun guessKind(host: String, srv: String, gw: Boolean, self: Boolean): String {
        if (gw) return "router"
        if (self) return "phone"
        val s = (host + " " + srv).lowercase()
        fun has(vararg k: String) = k.any { s.contains(it) }
        return when {
            has("iphone", "ipad", "android", "galaxy", "pixel", "oneplus", "xiaomi", "redmi", "huawei", "oppo", "realme", "phone") -> "phone"
            has("roku", "bravia", "webos", "tizen", "firetv", "appletv", "apple-tv", "-tv", "tv-") -> "tv"
            has("chromecast", "echo", "alexa", "sonos", "homepod", "speaker", "denon", "yamaha") -> "media"
            has("printer", "epson", "canon", "brother", "laserjet", "officejet", "mfp") -> "printer"
            has("macbook", "laptop", "desktop", "windows", "ubuntu", "linux", "imac", "thinkpad") -> "pc"
            has("camera", "hikvision", "dahua", "tuya", "esp", "plug", "bulb", "hue", "yeelight", "upnp") -> "iot"
            else -> "unknown"
        }
    }

    suspend fun scan(ctx: Context, info: NetInfo, onFound: suspend (Device) -> Unit): Unit = coroutineScope {
        val prefix = maxOf(info.prefix, 24)
        val mask = (0xFFFFFFFFL shl (32 - prefix)) and 0xFFFFFFFFL
        val base = ipToLong(info.ip) and mask
        val total = 1L shl (32 - prefix)
        val sem = Semaphore(48)
        val ss = async(Dispatchers.IO) { ssdp(ctx, 2500) }
        for (i in 1 until total - 1) {
            launch(Dispatchers.IO) {
                sem.withPermit {
                    val ip = longToIp(base + i)
                    val self = ip == info.ip
                    val ms = if (self) 0L else probe(ip)
                    if (ms >= 0) {
                        val mac = arp()[ip] ?: ""
                        var host = if (self) Build.MODEL else hostName(ip)
                        if (host.isBlank() && !self) host = mdnsName(ip)
                        if (host.isBlank() && !self) host = netbios(ip)
                        val srv = ss.await()[ip] ?: ""
                        val gw = ip == info.gateway
                        onFound(Device(ip, host, mac, ms, self, gw, guessKind(host, srv, gw, self), srv))
                    }
                }
            }
        }
    }

    suspend fun portScan(ip: String): List<Pair<Int, String>> = coroutineScope {
        ports.map { (p, name) ->
            async(Dispatchers.IO) {
                try {
                    Socket().use { it.connect(InetSocketAddress(ip, p), 400) }
                    p to name
                } catch (e: Exception) { null }
            }
        }.awaitAll().filterNotNull()
    }

    suspend fun tcpLatency(host: String, port: Int = 443): Long = withContext(Dispatchers.IO) {
        val s = System.nanoTime()
        try {
            Socket().use { it.connect(InetSocketAddress(host, port), 2000) }
            (System.nanoTime() - s) / 1_000_000
        } catch (e: Exception) { -1L }
    }

    suspend fun dnsTime(host: String): Long = withContext(Dispatchers.IO) {
        val s = System.nanoTime()
        try { InetAddress.getAllByName(host); (System.nanoTime() - s) / 1_000_000 }
        catch (e: Exception) { -1L }
    }

    suspend fun downloadMbps(): Double = withContext(Dispatchers.IO) {
        try {
            val c = URL("https://speed.cloudflare.com/__down?bytes=25000000").openConnection() as HttpURLConnection
            c.connectTimeout = 5000; c.readTimeout = 8000
            val s = System.nanoTime()
            var total = 0L
            val buf = ByteArray(65536)
            c.inputStream.use { i ->
                while (true) {
                    val r = i.read(buf)
                    if (r < 0) break
                    total += r
                    if (System.nanoTime() - s > 8_000_000_000L) break
                }
            }
            total * 8 / 1e6 / ((System.nanoTime() - s) / 1e9)
        } catch (e: Exception) { -1.0 }
    }
}
