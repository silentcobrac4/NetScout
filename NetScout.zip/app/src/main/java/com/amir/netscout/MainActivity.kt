package com.amir.netscout

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.ln

fun t(en: String, ar: String): String = if (Locale.getDefault().language == "ar") ar else en

fun fmtTime(v: Long): String =
    if (v == 0L) "—" else SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(v))

fun kindLabel(k: String): String = when (k) {
    "router" -> t("Router", "راوتر")
    "phone" -> t("Phone / tablet", "هاتف / جهاز لوحي")
    "tv" -> t("TV", "تلفاز")
    "media" -> t("Media / speaker", "جهاز وسائط / سماعة")
    "printer" -> t("Printer", "طابعة")
    "pc" -> t("Computer", "حاسوب")
    "iot" -> t("Smart device", "جهاز ذكي")
    "camera" -> t("Camera / recorder", "كاميرا / مسجّل")
    else -> t("Unknown type", "نوع غير معروف")
}

val accents = listOf(
    Color(0xFF1565C0), Color(0xFF00796B), Color(0xFF6A1B9A),
    Color(0xFFE65100), Color(0xFFC62828), Color(0xFF2E7D32)
)

sealed interface Page {
    data class Detail(val d: Device) : Page
    data class Tool(val id: String) : Page
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        if (Store.monitorMin > 0) Monitor.schedule(this, Store.monitorMin)
        setContent { NetTheme { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

@Composable
fun NetTheme(content: @Composable () -> Unit) {
    val dark = when (Store.mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val c = accents[Store.accent.coerceIn(0, accents.size - 1)]
    val scheme = if (dark) darkColorScheme(primary = lerp(c, Color.White, 0.35f), secondaryContainer = c.copy(alpha = 0.35f))
    else lightColorScheme(primary = c, secondaryContainer = c.copy(alpha = 0.18f))
    MaterialTheme(colorScheme = scheme, content = content)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var info by remember { mutableStateOf(Net.info(ctx)) }
    val devices = remember { mutableStateListOf<Device>() }
    var scanning by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf<Page?>(null) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { info = Net.info(ctx) }

    fun scan() {
        val i = Net.info(ctx)
        info = i
        if (i == null || scanning) return
        scanning = true
        devices.clear()
        scope.launch {
            Net.scan(ctx, i) { d -> withContext(Dispatchers.Main) { devices.add(d) } }
            Store.record(devices.toList())
            Store.setLast(devices.size)
            NetWidget.updateAll(ctx)
            Store.tick++
            scanning = false
        }
    }
    LaunchedEffect(Unit) {
        val req = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (android.os.Build.VERSION.SDK_INT >= 33) req.add("android.permission.POST_NOTIFICATIONS")
        perm.launch(req.toTypedArray())
        scan()
    }

    val pg = page
    if (pg != null) {
        BackHandler { page = null }
        when (pg) {
            is Page.Detail -> DeviceDetail(pg.d, info) { page = null }
            is Page.Tool -> ToolScreen(pg.id, info, devices.toList()) { page = null }
        }
        return
    }

    val tabs = listOf(
        t("Devices", "الأجهزة") to Icons.AutoMirrored.Filled.List,
        t("Tools", "الأدوات") to Icons.Default.Build,
        t("Wi-Fi", "الواي فاي") to Icons.Default.Search,
        t("Internet", "الإنترنت") to Icons.AutoMirrored.Filled.Send,
        t("Settings", "الإعدادات") to Icons.Default.Settings
    )
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(t("NetScout", "نت سكاوت")) },
                actions = {
                    if (tab == 0) IconButton(onClick = { scan() }) { Icon(Icons.Default.Refresh, null) }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Icon(icon, null) }, label = { Text(label, maxLines = 1) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> DevicesTab(devices, scanning, onOpen = { page = Page.Detail(it) })
                1 -> ToolsTab { page = Page.Tool(it) }
                2 -> WifiTab(info)
                3 -> InternetTab()
                else -> SettingsTab(devices)
            }
        }
    }
}

@Composable
fun KV(k: String, v: String) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(k, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(12.dp))
        Text(v)
    }
}

@Composable
fun Out(text: String) {
    if (text.isNotEmpty()) SelectionContainer {
        Text(text, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall)
    }
}

// ---------------- Devices ----------------

@Composable
fun DevicesTab(devices: List<Device>, scanning: Boolean, onOpen: (Device) -> Unit) {
    val ctxTick = Store.tick
    Column {
        if (scanning) LinearProgressIndicator(Modifier.fillMaxWidth())
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                "${devices.size} " + t("devices", "جهاز"),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.align(androidx.compose.ui.Alignment.CenterVertically)
            )
            if (ctxTick >= 0 && !Store.baseline() && devices.isNotEmpty()) {
                TextButton(onClick = { Store.trustAll(devices.toList()) }) {
                    Text(t("Mark all as known", "اعتبرها كلها معروفة"))
                }
            }
        }
        LazyColumn {
            items(devices.sortedBy { Net.ipToLong(it.ip) }) { d ->
                val m = Store.metaFor(d)
                val nick = m.nick
                val tag = when {
                    d.isSelf -> t("This device", "هذا الجهاز")
                    d.isGateway -> t("Router", "الراوتر")
                    d.kind == "camera" -> t("📷 Camera", "📷 كاميرا")
                    Store.baseline() && !m.trusted -> t("⚠ Unknown device", "⚠ جهاز غير معروف")
                    else -> null
                }
                ListItem(
                    overlineContent = if (tag != null) { { Text(tag) } } else null,
                    headlineContent = { Text(nick.ifBlank { d.host.ifBlank { d.ip } }) },
                    supportingContent = { Text(d.ip + " · " + kindLabel(d.kind) + (if (d.vendor.isNotBlank()) " · " + d.vendor else "")) },
                    trailingContent = { Text(if (d.pingMs >= 0) "${d.pingMs} ms" else "") },
                    modifier = Modifier.clickable { onOpen(d) }
                )
                HorizontalDivider()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeviceDetail(d: Device, info: NetInfo?, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val m = Store.metaFor(d)
    var nick by remember { mutableStateOf(m.nick) }
    var note by remember { mutableStateOf(m.note) }
    var mac by remember { mutableStateOf(m.mac.ifEmpty { d.mac }) }
    var trusted by remember { mutableStateOf(m.trusted) }
    var out by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    fun go(block: suspend () -> String) {
        busy = true; out = ""
        scope.launch { out = try { block() } catch (e: Exception) { "Error: ${e.message}" }; busy = false }
    }
    Scaffold(topBar = {
        TopAppBar(
            title = { Text(nick.ifBlank { d.host.ifBlank { d.ip } }) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }
        )
    }) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState())) {
            KV("IP", d.ip)
            if (d.host.isNotBlank()) KV(t("Name", "الاسم"), d.host)
            KV(t("Type", "النوع"), kindLabel(d.kind))
            if (d.vendor.isNotBlank()) KV(t("Vendor", "الشركة المصنّعة"), d.vendor)
            if (d.info.isNotBlank()) KV("UPnP", d.info)
            KV(t("First seen", "أول ظهور"), fmtTime(m.first))
            KV(t("Last seen", "آخر ظهور"), fmtTime(m.last))
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(nick, { nick = it; m.nick = it; Store.touch() }, Modifier.fillMaxWidth(),
                    label = { Text(t("Nickname", "اسم مخصص")) }, singleLine = true)
                OutlinedTextField(note, { note = it; m.note = it; Store.touch() }, Modifier.fillMaxWidth(),
                    label = { Text(t("Note", "ملاحظة")) })
                OutlinedTextField(mac, { mac = it; m.mac = it; Store.touch() }, Modifier.fillMaxWidth(),
                    label = { Text("MAC (AA:BB:CC:DD:EE:FF)") }, singleLine = true)
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text(t("Known device", "جهاز معروف"), Modifier.weight(1f))
                    Switch(trusted, { trusted = it; m.trusted = it; Store.touch() })
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(enabled = !busy, onClick = { go { Tools.ping(d.ip) } }) { Text("Ping") }
                    OutlinedButton(enabled = !busy, onClick = {
                        go {
                            val o = Net.portScan(d.ip)
                            if (o.isEmpty()) t("No open ports found", "لا توجد منافذ مفتوحة")
                            else o.joinToString("\n") { "${it.first}  ${it.second}" }
                        }
                    }) { Text(t("Ports", "المنافذ")) }
                    OutlinedButton(enabled = !busy, onClick = {
                        busy = true; out = ""
                        scope.launch { Tools.trace(d.ip) { out += it + "\n" }; busy = false }
                    }) { Text("Traceroute") }
                    OutlinedButton(enabled = !busy, onClick = { go { Tools.http(d.ip) } }) { Text("HTTP") }
                    OutlinedButton(enabled = !busy && mac.isNotBlank(), onClick = {
                        go { Tools.wol(mac, info?.let { Net.broadcast(it) } ?: "255.255.255.255") }
                    }) { Text("Wake-on-LAN") }
                }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                Out(out)
            }
        }
    }
}

// ---------------- Tools ----------------

fun toolName(id: String): String = when (id) {
    "ping" -> "Ping"
    "trace" -> "Traceroute"
    "dns" -> t("DNS lookup", "استعلام DNS")
    "whois" -> "WHOIS"
    "ports" -> t("Port scanner", "فاحص المنافذ")
    "wol" -> "Wake-on-LAN"
    "http" -> t("HTTP check", "فحص HTTP")
    "router" -> t("Router security check", "فحص أمان الراوتر")
    "ble" -> t("Bluetooth LE scanner", "ماسح بلوتوث BLE")
    "subnet" -> t("Subnet calculator", "حاسبة الشبكات الفرعية")
    "ssl" -> t("SSL certificate inspector", "فاحص شهادة SSL")
    "banner" -> t("Service banner grabber", "قراءة بانر الخدمة")
    "dnsbench" -> t("DNS speed benchmark", "مقارنة سرعة خوادم DNS")
    "channel" -> t("Best Wi-Fi channel", "أفضل قناة واي فاي")
    "iplookup" -> t("IP lookup", "معلومات عنوان IP")
    "vendor" -> t("MAC vendor lookup", "الشركة المصنّعة للـMAC")
    "traffic" -> t("Live traffic meter", "عدّاد حركة الشبكة المباشر")
    "heat" -> t("Home signal & speed map", "خريطة الإشارة والسرعة في المنزل")
    "firewall" -> t("App firewall", "جدار ناري للتطبيقات")
    "usage" -> t("Data usage per app", "استهلاك البيانات لكل تطبيق")
    "radar" -> t("Surveillance radar", "رادار التجسس والمتعقّبات")
    "cameras" -> t("Camera finder", "كاشف الكاميرات")
    "share" -> t("Share files (LAN)", "مشاركة الملفات (الشبكة)")
    else -> t("Password generator", "مولّد كلمات المرور")
}

@Composable
fun ToolsTab(onOpen: (String) -> Unit) {
    val groups = listOf(
        t("Guard & privacy", "الحماية والخصوصية") to listOf("firewall", "usage", "radar", "cameras"),
        t("Share", "المشاركة") to listOf("share"),
        t("Wi-Fi maps & analysis", "خرائط وتحليل الواي فاي") to listOf("heat", "channel", "router"),
        t("Network tools", "أدوات الشبكة") to listOf(
            "dnsbench", "ssl", "subnet", "banner", "iplookup", "vendor", "traffic",
            "ping", "trace", "dns", "whois", "ports", "wol", "http", "ble", "pass"
        )
    )
    LazyColumn {
        for ((title, ids) in groups) {
            item {
                Text(
                    title, Modifier.padding(16.dp, 16.dp, 16.dp, 4.dp),
                    style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary
                )
            }
            items(ids) { id ->
                ListItem(headlineContent = { Text(toolName(id)) }, modifier = Modifier.clickable { onOpen(id) })
                HorizontalDivider()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToolScreen(id: String, info: NetInfo?, devices: List<Device>, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember {
        mutableStateOf(
            when (id) {
                "ports", "router" -> info?.gateway ?: ""
                "dns", "http", "whois", "ssl" -> "example.com"
                "subnet" -> info?.let { it.ip + "/" + it.prefix } ?: "192.168.1.0/24"
                "banner" -> info?.gateway ?: ""
                "ping", "trace" -> "1.1.1.1"
                else -> ""
            }
        )
    }
    var extra by remember { mutableStateOf(when (id) { "ports" -> "1-1024"; "banner" -> "80"; else -> "A" }) }
    var out by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    fun go(block: suspend () -> String) {
        busy = true; out = ""
        scope.launch { out = try { block() } catch (e: Exception) { "Error: ${e.message}" }; busy = false }
    }
    Scaffold(topBar = {
        TopAppBar(
            title = { Text(toolName(id)) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (id) {
                "pass" -> PasswordGen()
                "ble" -> BleTool()
                "heat" -> HeatMap(info)
                "firewall" -> FirewallTool()
                "usage" -> UsageTool()
                "radar" -> RadarTool()
                "cameras" -> CameraTool(info, devices)
                "share" -> ShareTool(info)
                "traffic" -> TrafficTool()
                "router", "dnsbench", "channel" -> Button(enabled = !busy, onClick = {
                    go {
                        when (id) {
                            "router" -> Tools.routerCheck(ctx, info)
                            "dnsbench" -> Tools.dnsBench(info)
                            else -> Tools.channelAdvice(ctx)
                        }
                    }
                }) { Text(t("Run", "تشغيل")) }
                else -> {
                    OutlinedTextField(
                        input, { input = it }, Modifier.fillMaxWidth(), singleLine = true,
                        label = {
                            Text(
                                when (id) {
                                    "wol", "vendor" -> "MAC"
                                    "subnet" -> "CIDR"
                                    "iplookup" -> t("IP (empty = mine)", "IP (فارغ = الخاص بي)")
                                    else -> t("Host / address", "العنوان")
                                }
                            )
                        }
                    )
                    if (id == "dns") Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (ty in listOf("A", "AAAA", "MX", "TXT", "NS")) {
                            FilterChip(selected = extra == ty, onClick = { extra = ty }, label = { Text(ty) })
                        }
                    }
                    if (id == "ports" || id == "banner") OutlinedTextField(
                        extra, { extra = it }, Modifier.fillMaxWidth(), singleLine = true,
                        label = { Text(if (id == "ports") t("Ports (e.g. 1-1024,8080)", "المنافذ (مثال 1-1024,8080)") else t("Port", "المنفذ")) }
                    )
                    Button(enabled = !busy && (input.isNotBlank() || id == "iplookup"), onClick = {
                        val h = input.trim()
                        when (id) {
                            "ping" -> go { Tools.ping(h) }
                            "trace" -> {
                                busy = true; out = ""
                                scope.launch { Tools.trace(h) { out += it + "\n" }; busy = false }
                            }
                            "dns" -> go { Tools.dns(h, extra) }
                            "whois" -> go { Tools.whois(h) }
                            "http" -> go { Tools.http(h) }
                            "ports" -> go {
                                val ps = Tools.parsePorts(extra)
                                val open = Tools.scanPorts(h, ps)
                                "Scanned ${ps.size} ports\n" +
                                    (if (open.isEmpty()) "No open ports" else open.joinToString("\n") { "$it  ${Net.ports[it] ?: ""}" })
                            }
                            "wol" -> go { Tools.wol(h, info?.let { Net.broadcast(it) } ?: "255.255.255.255") }
                            "subnet" -> go { Tools.subnet(h) }
                            "ssl" -> go { Tools.ssl(h) }
                            "banner" -> go { Tools.banner(h, extra.trim().toIntOrNull() ?: 80) }
                            "iplookup" -> go { Tools.ipLookup(h) }
                            "vendor" -> go { Vendor.describe(ctx, h) }
                            else -> {}
                        }
                    }) { Text(t("Run", "تشغيل")) }
                }
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            Out(out)
        }
    }
}

@Composable
fun PasswordGen() {
    val clip = LocalClipboardManager.current
    var len by remember { mutableFloatStateOf(20f) }
    var up by remember { mutableStateOf(true) }
    var low by remember { mutableStateOf(true) }
    var dig by remember { mutableStateOf(true) }
    var sym by remember { mutableStateOf(true) }
    var pwd by remember { mutableStateOf("") }
    fun gen() {
        val pools = mutableListOf<String>()
        if (up) pools.add("ABCDEFGHJKLMNPQRSTUVWXYZ")
        if (low) pools.add("abcdefghijkmnopqrstuvwxyz")
        if (dig) pools.add("23456789")
        if (sym) pools.add("!@#\$%^&*()-_=+[]{};:,.?")
        if (pools.isEmpty()) { pwd = ""; return }
        val r = SecureRandom()
        val all = pools.joinToString("")
        val chars = MutableList(len.toInt()) { all[r.nextInt(all.length)] }
        for ((i, p) in pools.withIndex()) if (i < chars.size) chars[i] = p[r.nextInt(p.length)]
        chars.shuffle(r)
        pwd = chars.joinToString("")
    }
    val poolSize = (if (up) 24 else 0) + (if (low) 25 else 0) + (if (dig) 8 else 0) + (if (sym) 22 else 0)
    val bits = if (poolSize > 0) (len.toInt() * ln(poolSize.toDouble()) / ln(2.0)).toInt() else 0
    Text(t("Length: ", "الطول: ") + len.toInt())
    Slider(len, { len = it }, valueRange = 8f..64f)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
        FilterChip(up, { up = !up }, { Text("A-Z") })
        FilterChip(low, { low = !low }, { Text("a-z") })
        FilterChip(dig, { dig = !dig }, { Text("0-9") })
        FilterChip(sym, { sym = !sym }, { Text("#$%") })
    }
    Button(onClick = { gen() }) { Text(t("Generate", "توليد")) }
    if (pwd.isNotEmpty()) {
        SelectionContainer { Text(pwd, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.titleMedium) }
        Text(t("Strength: ", "القوة: ") + "$bits bits", color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedButton(onClick = { clip.setText(AnnotatedString(pwd)) }) { Text(t("Copy", "نسخ")) }
    }
}

@SuppressLint("MissingPermission")
@Composable
fun BleTool() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf<List<Ble>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    fun start() {
        busy = true
        scope.launch { list = Tools.bleScan(ctx); busy = false }
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { start() }
    Button(enabled = !busy, onClick = {
        val req = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (android.os.Build.VERSION.SDK_INT >= 31) req.add("android.permission.BLUETOOTH_SCAN")
        perm.launch(req.toTypedArray())
    }) { Text(t("Scan (8 s)", "فحص (8 ثوانٍ)")) }
    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
    for (b in list) KV(b.name.ifBlank { b.addr }, "${b.rssi} dBm")
}

// ---------------- Wi-Fi ----------------

@Composable
fun WifiTab(i: NetInfo?) {
    val ctx = LocalContext.current
    var aps by remember { mutableStateOf<List<Ap>>(emptyList()) }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        if (i == null) {
            Text(t("Not connected to Wi-Fi", "غير متصل بشبكة واي فاي"), Modifier.padding(16.dp))
        } else {
            KV(t("Network name", "اسم الشبكة"), i.ssid)
            KV(t("IP address", "عنوان IP"), i.ip + "/" + i.prefix)
            KV(t("Router", "الراوتر"), i.gateway)
            KV("DNS", i.dns)
            KV(t("Link speed", "سرعة الاتصال"), "${i.speedMbps} Mbps")
            KV(t("Signal", "الإشارة"), "${i.rssi} dBm")
            KV(t("Frequency", "التردد"), "${i.freqMhz} MHz")
        }
        Button(onClick = { aps = Tools.wifiScan(ctx) }, modifier = Modifier.padding(16.dp)) {
            Text(t("Scan nearby networks", "فحص الشبكات القريبة"))
        }
        if (aps.isNotEmpty()) {
            val busy = aps.groupBy { it.channel }.entries.sortedBy { it.key }
                .joinToString("   ") { "ch${it.key}: ${it.value.size}" }
            Text(t("Channel usage: ", "استخدام القنوات: ") + busy, Modifier.padding(horizontal = 16.dp))
        }
        for (a in aps) {
            ListItem(
                headlineContent = { Text(a.ssid.ifBlank { "(hidden)" }) },
                supportingContent = { Text("ch${a.channel} · ${a.freq} MHz · ${a.sec}") },
                trailingContent = { Text("${a.level} dBm") }
            )
            LinearProgressIndicator(
                progress = { ((a.level + 100) / 60f).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            )
        }
    }
}

// ---------------- Internet ----------------

@Composable
fun SpeedChart(recs: List<SpeedRec>) {
    val dc = MaterialTheme.colorScheme.primary
    val uc = MaterialTheme.colorScheme.tertiary
    val grid = MaterialTheme.colorScheme.outlineVariant
    Canvas(Modifier.fillMaxWidth().height(160.dp).padding(16.dp)) {
        if (recs.size < 2) return@Canvas
        val mx = maxOf(recs.maxOf { maxOf(it.down, it.up) }, 1.0).toFloat()
        val dx = size.width / (recs.size - 1)
        fun pt(i: Int, v: Double) = Offset(i * dx, size.height - (maxOf(v, 0.0).toFloat() / mx) * size.height)
        drawLine(grid, Offset(0f, size.height), Offset(size.width, size.height), 2f)
        for (i in 1 until recs.size) {
            drawLine(dc, pt(i - 1, recs[i - 1].down), pt(i, recs[i].down), 5f)
            drawLine(uc, pt(i - 1, recs[i - 1].up), pt(i, recs[i].up), 5f)
        }
    }
}

@Composable
fun InternetTab() {
    val scope = rememberCoroutineScope()
    val tick = Store.tick
    var lat by remember { mutableStateOf<Long?>(null) }
    var dns by remember { mutableStateOf<Long?>(null) }
    var down by remember { mutableStateOf<Double?>(null) }
    var up by remember { mutableStateOf<Double?>(null) }
    var ip by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Button(
            enabled = !busy,
            onClick = {
                busy = true; lat = null; dns = null; down = null; up = null; ip = ""
                scope.launch {
                    lat = Net.tcpLatency("1.1.1.1")
                    dns = Net.dnsTime("example.com")
                    ip = Tools.publicIp()
                    down = Net.downloadMbps()
                    up = Tools.upMbps()
                    Store.addSpeed(SpeedRec(System.currentTimeMillis(), down ?: -1.0, up ?: -1.0, lat ?: -1))
                    busy = false
                }
            },
            modifier = Modifier.padding(16.dp)
        ) { Text(t("Run speed test", "ابدأ اختبار السرعة")) }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (ip.isNotEmpty()) KV(t("Public IP", "IP العام"), ip)
        lat?.let { KV(t("Latency", "زمن الاستجابة"), if (it >= 0) "$it ms" else "×") }
        dns?.let { KV(t("DNS lookup", "زمن DNS"), if (it >= 0) "$it ms" else "×") }
        down?.let { KV(t("Download", "التحميل"), if (it >= 0) "%.1f Mbps".format(it) else "×") }
        up?.let { KV(t("Upload", "الرفع"), if (it >= 0) "%.1f Mbps".format(it) else "×") }
        if (tick >= 0 && Store.speeds.size >= 2) {
            Text(t("History (download / upload)", "السجل (تحميل / رفع)"), Modifier.padding(start = 16.dp, top = 16.dp),
                style = MaterialTheme.typography.titleSmall)
            SpeedChart(Store.speeds.takeLast(20))
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("● " + t("Download", "التحميل"), color = MaterialTheme.colorScheme.primary)
                Text("● " + t("Upload", "الرفع"), color = MaterialTheme.colorScheme.tertiary)
            }
        }
    }
}

// ---------------- Settings ----------------

@Composable
fun SettingsTab(devices: List<Device>) {
    val ctx = LocalContext.current
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(t("Theme", "المظهر"), style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(t("System", "النظام"), t("Light", "فاتح"), t("Dark", "داكن")).forEachIndexed { i, l ->
                FilterChip(selected = Store.mode == i, onClick = { Store.mode = i; Store.touch() }, label = { Text(l) })
            }
        }
        Text(t("Accent color", "اللون الأساسي"), style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            accents.forEachIndexed { i, c ->
                Box(
                    Modifier.size(36.dp).clip(CircleShape).background(c)
                        .border(if (Store.accent == i) 3.dp else 0.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                        .clickable { Store.accent = i; Store.touch() }
                )
            }
        }
        Text(t("Intruder alerts (background check)", "تنبيه الأجهزة المتطفلة (فحص بالخلفية)"), style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0, 15, 30, 60).forEach { m ->
                FilterChip(
                    selected = Store.monitorMin == m,
                    onClick = { Store.monitorMin = m; Store.touch(); Monitor.schedule(ctx, m) },
                    label = { Text(if (m == 0) t("Off", "إيقاف") else "$m min") }
                )
            }
        }
        Text(
            t("First mark your current devices as known (Devices tab). New unknown devices then trigger a notification.",
                "أولاً اعتبر أجهزتك الحالية معروفة (تبويب الأجهزة). بعدها أي جهاز جديد غير معروف سيصلك تنبيه عنه."),
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(t("Export report", "تصدير تقرير"), style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { Store.share(ctx, Store.csvFile(ctx, devices.toList()), "text/csv") }) { Text("CSV") }
            Button(onClick = { Store.share(ctx, Store.pdfFile(ctx, devices.toList()), "application/pdf") }) { Text("PDF") }
            Button(onClick = { Store.share(ctx, Dashboard.file(ctx, devices.toList(), Net.info(ctx)), "text/html") }) { Text("HTML") }
        }
    }
}

// ---------------- Heatmap & traffic ----------------

fun heatColor(rssi: Double): Color {
    val f = ((rssi + 90) / 50).coerceIn(0.0, 1.0).toFloat()
    return if (f < 0.5f) lerp(Color(0xFFD32F2F), Color(0xFFFBC02D), f * 2)
    else lerp(Color(0xFFFBC02D), Color(0xFF388E3C), (f - 0.5f) * 2)
}

@Composable
fun HeatMap(info: NetInfo?) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val key = info?.ssid ?: "—"
    val sig = remember(key) { mutableStateMapOf<Int, Int>().apply { putAll(Store.heat[key] ?: emptyMap()) } }
    val spd = remember(key) { mutableStateMapOf<Int, Int>().apply { putAll(Store.heatSpeed[key] ?: emptyMap()) } }
    var mode by remember { mutableIntStateOf(0) }
    var sel by remember { mutableIntStateOf(-1) }
    var busy by remember { mutableStateOf(false) }
    var interp by remember { mutableStateOf(true) }
    val cols = 8
    val rows = 10
    val line = MaterialTheme.colorScheme.outlineVariant
    val data = if (mode == 0) sig else spd
    val mx = maxOf((spd.values.maxOrNull() ?: 0) / 10.0, 10.0)
    fun colorOf(x: Double): Color =
        if (mode == 0) heatColor(x) else heatColor(-90.0 + 50.0 * ((x / 10.0) / mx).coerceIn(0.0, 1.0))
    fun save() {
        Store.heat[key] = HashMap(sig)
        Store.heatSpeed[key] = HashMap(spd)
        Store.touch()
    }

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(mode == 0, { mode = 0; sel = -1 }, { Text(t("Signal", "الإشارة")) })
        FilterChip(mode == 1, { mode = 1; sel = -1 }, { Text(t("Speed", "السرعة")) })
    }
    Text(
        t("Draw your home as a grid. Stand in a spot, tap the matching cell and hold still. Signal takes 2 s; speed runs a short download test (about 4 s). Long-press a cell to delete it.",
            "تخيّل بيتك كشبكة. قف في مكان، اضغط على الخانة المقابلة له وابقَ ثابتاً. الإشارة تأخذ ثانيتين، والسرعة تجري اختبار تحميل قصيراً (نحو 4 ثوانٍ). اضغط مطولاً لحذف الخانة."),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Canvas(
        Modifier.fillMaxWidth().aspectRatio(cols / rows.toFloat()).border(1.dp, line)
            .pointerInput(key, mode) {
                detectTapGestures(
                    onTap = { o ->
                        val c = (o.x / size.width * cols).toInt().coerceIn(0, cols - 1)
                        val r = (o.y / size.height * rows).toInt().coerceIn(0, rows - 1)
                        val idx = r * cols + c
                        sel = idx
                        if (!busy) {
                            busy = true
                            scope.launch {
                                if (mode == 0) {
                                    val v = Tools.sampleRssi(ctx)
                                    if (v != null) { sig[idx] = v; save() }
                                } else {
                                    val v = Net.downloadMbps(8_000_000, 4000)
                                    if (v >= 0) { spd[idx] = (v * 10).toInt(); save() }
                                }
                                busy = false
                            }
                        }
                    },
                    onLongPress = { o ->
                        val c = (o.x / size.width * cols).toInt().coerceIn(0, cols - 1)
                        val r = (o.y / size.height * rows).toInt().coerceIn(0, rows - 1)
                        data.remove(r * cols + c)
                        save()
                    }
                )
            }
    ) {
        val cw = size.width / cols
        val ch = size.height / rows
        for (r in 0 until rows) for (c in 0 until cols) {
            val idx = r * cols + c
            val m = data[idx]
            val color: Color? = when {
                m != null -> colorOf(m.toDouble())
                interp && data.isNotEmpty() -> {
                    var num = 0.0
                    var den = 0.0
                    for ((k, v) in data) {
                        val dr = (k / cols - r).toDouble()
                        val dc = (k % cols - c).toDouble()
                        val w = 1.0 / (dr * dr + dc * dc)
                        num += w * v
                        den += w
                    }
                    colorOf(num / den).copy(alpha = 0.5f)
                }
                else -> null
            }
            if (color != null) drawRect(color, Offset(c * cw, r * ch), Size(cw, ch))
            if (idx == sel) drawRect(Color.White, Offset(c * cw, r * ch), Size(cw, ch), style = Stroke(4f))
        }
        for (c in 1 until cols) drawLine(line, Offset(c * cw, 0f), Offset(c * cw, size.height), 1f)
        for (r in 1 until rows) drawLine(line, Offset(0f, r * ch), Offset(size.width, r * ch), 1f)
    }
    if (busy) {
        LinearProgressIndicator(Modifier.fillMaxWidth())
        Text(t("Measuring… stand still", "جارٍ القياس… ابقَ ثابتاً"))
    }
    if (sel >= 0) data[sel]?.let {
        Text(t("Selected cell: ", "الخانة المحددة: ") + (if (mode == 0) "$it dBm" else String.format(java.util.Locale.US, "%.1f Mbps", it / 10.0)))
    }
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Text(if (mode == 0) t("Weak", "ضعيفة") else t("Slow", "بطيئة"), style = MaterialTheme.typography.labelSmall)
        for (v in listOf(-90, -80, -70, -60, -50)) Box(Modifier.size(width = 28.dp, height = 12.dp).background(heatColor(v.toDouble())))
        Text(if (mode == 0) t("Strong", "قوية") else t("Fast", "سريعة"), style = MaterialTheme.typography.labelSmall)
    }
    if (data.isNotEmpty()) {
        val worst = data.values.minOrNull() ?: 0
        val avg = data.values.sum() / data.size
        val fmt: (Int) -> String = { if (mode == 0) "$it dBm" else String.format(java.util.Locale.US, "%.1f Mbps", it / 10.0) }
        Text(t("Cells: ", "الخانات: ") + data.size + "  ·  " + t("Average: ", "المتوسط: ") + fmt(avg) + "  ·  " + t("Worst: ", "الأسوأ: ") + fmt(worst))
    }
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Text(t("Fill gaps (estimate)", "تقدير الخانات الفارغة"), Modifier.weight(1f))
        Switch(interp, { interp = it })
    }
    OutlinedButton(onClick = { data.clear(); sel = -1; save() }) { Text(t("Clear this map", "مسح هذه الخريطة")) }
}

@Composable
fun TrafficTool() {
    val hist = remember { mutableStateListOf<SpeedRec>() }
    var cur by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        var rx = android.net.TrafficStats.getTotalRxBytes()
        var tx = android.net.TrafficStats.getTotalTxBytes()
        while (true) {
            delay(1000)
            val nrx = android.net.TrafficStats.getTotalRxBytes()
            val ntx = android.net.TrafficStats.getTotalTxBytes()
            val d = (nrx - rx) * 8 / 1e6
            val u = (ntx - tx) * 8 / 1e6
            rx = nrx
            tx = ntx
            hist.add(SpeedRec(System.currentTimeMillis(), d, u, 0))
            if (hist.size > 40) hist.removeAt(0)
            cur = "↓ %.2f Mbps    ↑ %.2f Mbps".format(d, u)
        }
    }
    Text(cur.ifEmpty { "…" }, style = MaterialTheme.typography.titleLarge)
    SpeedChart(hist.toList())
    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("● " + t("Download", "التحميل"), color = MaterialTheme.colorScheme.primary)
        Text("● " + t("Upload", "الرفع"), color = MaterialTheme.colorScheme.tertiary)
    }
}
