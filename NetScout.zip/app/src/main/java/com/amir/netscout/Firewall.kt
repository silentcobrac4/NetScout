package com.amir.netscout

import android.Manifest
import android.app.AppOpsManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.os.Process
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.FileInputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.Calendar

data class Attempt(val pkg: String, val dst: String, val count: Int)
data class AppEntry(val pkg: String, val label: String, val system: Boolean)
data class AppUse(val uid: Int, val pkg: String, val label: String, val wifi: Long, val mobile: Long)

object FirewallStore {
    var running by mutableStateOf(false)
    private val log = LinkedHashMap<String, Attempt>()
    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences("fw", Context.MODE_PRIVATE)

    fun blocked(ctx: Context): Set<String> = HashSet(sp(ctx).getStringSet("blocked", emptySet()) ?: emptySet())
    fun enabled(ctx: Context): Boolean = sp(ctx).getBoolean("enabled", false)
    fun setEnabled(ctx: Context, on: Boolean) { sp(ctx).edit().putBoolean("enabled", on).apply() }
    fun setBlocked(ctx: Context, pkg: String, on: Boolean) {
        val s = blocked(ctx).toMutableSet()
        if (on) s.add(pkg) else s.remove(pkg)
        sp(ctx).edit().putStringSet("blocked", s).apply()
    }

    @Synchronized
    fun record(pkg: String, dst: String) {
        val k = "$pkg>$dst"
        val a = log[k]
        log[k] = Attempt(pkg, dst, (a?.count ?: 0) + 1)
        if (log.size > 300) log.remove(log.keys.first())
    }

    @Synchronized
    fun snapshot(): List<Attempt> = log.values.sortedByDescending { it.count }

    @Synchronized
    fun clear() { log.clear() }
}

object Firewall {
    fun apply(ctx: Context) {
        val c = ctx.applicationContext
        c.startService(Intent(c, FirewallService::class.java))
    }

    fun stop(ctx: Context) {
        val c = ctx.applicationContext
        c.startService(Intent(c, FirewallService::class.java).setAction("stop"))
    }
}

/**
 * Per-app firewall. Only the blocked apps are routed into this local VPN, and every packet
 * they send is dropped (nothing is forwarded). All other apps are untouched.
 */
class FirewallService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    @Volatile private var alive = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "stop") { stopVpn(); stopSelf(); return START_NOT_STICKY }
        val blocked = FirewallStore.blocked(this)
        if (blocked.isEmpty() || !FirewallStore.enabled(this)) { stopVpn(); stopSelf(); return START_NOT_STICKY }
        stopVpn()
        val b = Builder().setSession("NetScout Firewall")
            .addAddress("10.77.0.1", 32).addRoute("0.0.0.0", 0)
            .addAddress("fd77:7700::1", 128).addRoute("::", 0)
        var added = 0
        for (p in blocked) {
            try { b.addAllowedApplication(p); added++ } catch (e: Exception) { }
        }
        if (added == 0) { stopSelf(); return START_NOT_STICKY }
        val fd = try { b.establish() } catch (e: Exception) { null }
        if (fd == null) { stopSelf(); return START_NOT_STICKY }
        tun = fd
        alive = true
        FirewallStore.running = true
        Thread { drain(fd) }.start()
        return START_STICKY
    }

    private fun drain(fd: ParcelFileDescriptor) {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val input = FileInputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        try {
            while (alive) {
                val n = input.read(buf)
                if (n < 20) continue
                if ((buf[0].toInt() shr 4) != 4) continue
                val ihl = (buf[0].toInt() and 15) * 4
                val proto = buf[9].toInt() and 255
                val src = InetAddress.getByAddress(buf.copyOfRange(12, 16))
                val dst = InetAddress.getByAddress(buf.copyOfRange(16, 20))
                var sp = 0
                var dp = 0
                if ((proto == 6 || proto == 17) && n >= ihl + 4) {
                    sp = ((buf[ihl].toInt() and 255) shl 8) or (buf[ihl + 1].toInt() and 255)
                    dp = ((buf[ihl + 2].toInt() and 255) shl 8) or (buf[ihl + 3].toInt() and 255)
                }
                var pkg = "?"
                if (android.os.Build.VERSION.SDK_INT >= 29 && sp != 0) {
                    try {
                        val uid = cm.getConnectionOwnerUid(proto, InetSocketAddress(src, sp), InetSocketAddress(dst, dp))
                        if (uid >= 0) pkg = packageManager.getPackagesForUid(uid)?.firstOrNull() ?: "uid $uid"
                    } catch (e: Exception) { }
                }
                FirewallStore.record(pkg, dst.hostAddress + ":" + dp + (if (proto == 17) " UDP" else ""))
            }
        } catch (e: Exception) { }
    }

    private fun stopVpn() {
        alive = false
        try { tun?.close() } catch (e: Exception) { }
        tun = null
        FirewallStore.running = false
    }

    override fun onRevoke() { stopVpn(); super.onRevoke() }
    override fun onDestroy() { stopVpn(); super.onDestroy() }
}

object Apps {
    fun list(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        return pm.getInstalledApplications(0)
            .filter {
                it.packageName != ctx.packageName &&
                    pm.checkPermission(Manifest.permission.INTERNET, it.packageName) == PackageManager.PERMISSION_GRANTED
            }
            .map { AppEntry(it.packageName, pm.getApplicationLabel(it).toString(), (it.flags and ApplicationInfo.FLAG_SYSTEM) != 0) }
            .sortedBy { it.label.lowercase() }
    }
}

/** Per-app data usage from Android's own statistics (needs the "usage access" permission). */
object Usage {
    @Suppress("DEPRECATION")
    fun hasAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun startOfDay(now: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = now
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    @Suppress("DEPRECATION")
    fun query(ctx: Context, days: Int): List<AppUse> {
        val nsm = ctx.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
        val end = System.currentTimeMillis()
        val start = if (days == 0) startOfDay(end) else end - days * 86_400_000L
        val wifi = HashMap<Int, Long>()
        val mob = HashMap<Int, Long>()
        fun add(type: Int, into: HashMap<Int, Long>) {
            try {
                val st = nsm.querySummary(type, null, start, end)
                val b = NetworkStats.Bucket()
                while (st.hasNextBucket()) {
                    st.getNextBucket(b)
                    into[b.uid] = (into[b.uid] ?: 0L) + b.rxBytes + b.txBytes
                }
                st.close()
            } catch (e: Exception) { }
        }
        add(ConnectivityManager.TYPE_WIFI, wifi)
        add(ConnectivityManager.TYPE_MOBILE, mob)
        val pm = ctx.packageManager
        return (wifi.keys + mob.keys).map { uid ->
            val pkg = pm.getPackagesForUid(uid)?.firstOrNull() ?: ""
            val label = try {
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) {
                when (uid) { 1000 -> "Android System"; -4 -> "Removed apps"; -5 -> "Tethering"; else -> "uid $uid" }
            }
            AppUse(uid, pkg, label, wifi[uid] ?: 0L, mob[uid] ?: 0L)
        }.sortedByDescending { it.wifi + it.mobile }.take(60)
    }
}
