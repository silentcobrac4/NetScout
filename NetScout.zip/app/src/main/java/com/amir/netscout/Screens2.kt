package com.amir.netscout

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.provider.Settings
import android.webkit.MimeTypeMap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Collections
import java.util.Locale

fun fmtBytes(b: Long): String = when {
    b >= (1L shl 30) -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
    b >= (1L shl 20) -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
    b >= (1L shl 10) -> String.format(Locale.US, "%.0f KB", b / 1024.0)
    else -> "$b B"
}

// ---------------- Firewall ----------------

@Composable
fun FirewallTool() {
    val ctx = LocalContext.current
    var enabled by remember { mutableStateOf(FirewallStore.enabled(ctx)) }
    var blocked by remember { mutableStateOf(FirewallStore.blocked(ctx)) }
    var query by remember { mutableStateOf("") }
    var showSystem by remember { mutableStateOf(false) }
    var apps by remember { mutableStateOf<List<AppEntry>>(emptyList()) }
    var log by remember { mutableStateOf<List<Attempt>>(emptyList()) }
    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { Apps.list(ctx) } }
    LaunchedEffect(Unit) {
        while (true) {
            log = FirewallStore.snapshot()
            delay(1500)
        }
    }
    val vpn = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            FirewallStore.setEnabled(ctx, true); enabled = true; Firewall.apply(ctx)
        }
    }
    fun turnOn() {
        val i = VpnService.prepare(ctx)
        if (i == null) { FirewallStore.setEnabled(ctx, true); enabled = true; Firewall.apply(ctx) } else vpn.launch(i)
    }
    fun turnOff() { FirewallStore.setEnabled(ctx, false); enabled = false; Firewall.stop(ctx) }

    Text(
        t("Choose apps to cut off from the internet. Only the apps you block are affected; everything else works normally. Uses a local VPN that drops their traffic (nothing leaves your phone).",
            "اختر التطبيقات التي تريد قطع الإنترنت عنها. التطبيقات المحجوبة فقط تتأثر وكل شيء آخر يعمل طبيعياً. يستخدم VPN محلياً يُسقط حركتها (لا شيء يغادر هاتفك)."),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(t("Firewall", "الجدار الناري") + if (FirewallStore.running) "  ●" else "", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
        Switch(enabled, { if (it) turnOn() else turnOff() })
    }
    OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(t("Search apps", "ابحث عن تطبيق")) })
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(t("Show system apps", "إظهار تطبيقات النظام"), Modifier.weight(1f))
        Switch(showSystem, { showSystem = it })
    }
    val shown = apps.filter {
        (showSystem || !it.system) && (query.isBlank() || it.label.contains(query, true) || it.pkg.contains(query, true))
    }.take(150)
    for (a in shown) {
        ListItem(
            headlineContent = { Text(a.label) },
            supportingContent = { Text(a.pkg, style = MaterialTheme.typography.labelSmall) },
            trailingContent = {
                Switch(a.pkg in blocked, { on ->
                    FirewallStore.setBlocked(ctx, a.pkg, on)
                    blocked = FirewallStore.blocked(ctx)
                    if (enabled) Firewall.apply(ctx)
                })
            }
        )
    }
    if (log.isNotEmpty()) {
        Text(t("Blocked attempts", "محاولات اتصال محجوبة"), style = MaterialTheme.typography.titleSmall)
        for (x in log.take(30)) {
            val name = apps.firstOrNull { it.pkg == x.pkg }?.label ?: x.pkg
            Text("${x.count}×  $name → ${x.dst}", fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall)
        }
        OutlinedButton(onClick = { FirewallStore.clear(); log = emptyList() }) { Text(t("Clear log", "مسح السجل")) }
    }
}

// ---------------- Per-app usage ----------------

@Composable
fun UsageTool() {
    val ctx = LocalContext.current
    var has by remember { mutableStateOf(Usage.hasAccess(ctx)) }
    var days by remember { mutableIntStateOf(0) }
    var list by remember { mutableStateOf<List<AppUse>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var blocked by remember { mutableStateOf(FirewallStore.blocked(ctx)) }
    LaunchedEffect(days, has) {
        if (has) {
            busy = true
            list = withContext(Dispatchers.IO) { Usage.query(ctx, days) }
            busy = false
        }
    }
    if (!has) {
        Text(
            t("To see which apps use your data, allow \"Usage access\" for NetScout, then come back and tap the second button.",
                "لمعرفة أي التطبيقات تستهلك بياناتك، فعّل \"الوصول إلى بيانات الاستخدام\" لـ NetScout، ثم ارجع واضغط الزر الثاني."),
            style = MaterialTheme.typography.bodySmall
        )
        Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) {
            Text(t("Open usage access settings", "فتح إعدادات الوصول"))
        }
        OutlinedButton(onClick = { has = Usage.hasAccess(ctx) }) { Text(t("I enabled it", "فعّلتها")) }
        return
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(0 to t("Today", "اليوم"), 7 to t("7 days", "7 أيام"), 30 to t("30 days", "30 يوماً")).forEach { (d, l) ->
            FilterChip(days == d, { days = d }, { Text(l) })
        }
    }
    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
    Text(t("Tap an app to block or unblock it in the firewall.", "اضغط على تطبيق لحجبه أو إلغاء حجبه في الجدار الناري."),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    for (u in list) {
        val isBlocked = u.pkg in blocked
        ListItem(
            headlineContent = { Text(u.label) },
            supportingContent = { Text("Wi-Fi ${fmtBytes(u.wifi)} · " + t("Mobile ", "موبايل ") + fmtBytes(u.mobile)) },
            trailingContent = { Text(if (isBlocked) "🚫" else fmtBytes(u.wifi + u.mobile)) },
            modifier = Modifier.clickable(enabled = u.pkg.isNotEmpty()) {
                FirewallStore.setBlocked(ctx, u.pkg, !isBlocked)
                blocked = FirewallStore.blocked(ctx)
                if (FirewallStore.enabled(ctx)) Firewall.apply(ctx)
            }
        )
    }
}

// ---------------- Radar ----------------

data class SeenHit(val hit: RadarHit, val first: Long, val last: Long, val count: Int)

private fun effSev(s: SeenHit): Int =
    if (s.hit.key.startsWith("ble:") && (s.last - s.first) > 10 * 60_000L) 2 else s.hit.severity

@Composable
fun RadarTool() {
    val ctx = LocalContext.current
    val seen = remember { mutableStateMapOf<String, SeenHit>() }
    var watching by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var rounds by remember { mutableIntStateOf(0) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { watching = true }
    LaunchedEffect(watching) {
        while (watching) {
            busy = true
            val hits = Tools.radarScan(ctx)
            val now = System.currentTimeMillis()
            for (h in hits) {
                val o = seen[h.key]
                seen[h.key] = SeenHit(h, o?.first ?: now, now, (o?.count ?: 0) + 1)
            }
            rounds++
            busy = false
            delay(3000)
        }
    }
    Text(
        t("Looks around you for trackers (AirTag, Tile, SmartTag) and suspicious Wi-Fi (fake twins, honeypots, fake-network floods). Keep it running while you move: a tracker that stays with you for 10+ minutes is escalated. Detection only: nothing is transmitted.",
            "يفحص حولك بحثاً عن متعقّبات (AirTag وTile وSmartTag) وواي فاي مشبوه (شبكات توأم مزيفة، فخاخ، فيض شبكات وهمية). اتركه يعمل أثناء تنقلك: المتعقّب الذي يبقى معك أكثر من 10 دقائق يُصعَّد تنبيهه. كشف فقط: لا يرسل شيئاً."),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Button(onClick = {
        if (watching) watching = false else {
            val req = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
            if (android.os.Build.VERSION.SDK_INT >= 31) req.add("android.permission.BLUETOOTH_SCAN")
            perm.launch(req.toTypedArray())
        }
    }) { Text(if (watching) t("Stop watching", "إيقاف المراقبة") else t("Start watching", "ابدأ المراقبة")) }
    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
    if (rounds > 0 && seen.isEmpty()) Text(t("Nothing suspicious found so far.", "لم يُعثر على شيء مشبوه حتى الآن."))
    val sorted = seen.values.sortedWith(compareByDescending<SeenHit> { effSev(it) }.thenBy { it.first })
    for (s in sorted) {
        val mins = (s.last - s.first) / 60_000L
        ListItem(
            overlineContent = {
                Text(when (effSev(s)) { 2 -> "⚠ " + t("Alert", "تنبيه"); 1 -> t("Warning", "تحذير"); else -> t("Info", "معلومة") })
            },
            headlineContent = { Text(s.hit.title) },
            supportingContent = { Text(s.hit.detail + " · " + t("seen ", "شوهد ") + mins + t(" min", " د") + " · " + s.count + "×") }
        )
    }
}

// ---------------- Camera finder ----------------

@Composable
fun CameraTool(info: NetInfo?, devices: List<Device>) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var found by remember { mutableStateOf(devices.filter { it.kind == "camera" }) }
    var busy by remember { mutableStateOf(false) }
    var scanned by remember { mutableStateOf(false) }
    Text(
        t("Finds IP cameras, DVR/NVR recorders and baby monitors on this Wi-Fi using ONVIF discovery, video ports (RTSP etc.), vendor names and device names. It never tries to log in. Cameras that record locally or use mobile data will not appear here.",
            "يبحث عن كاميرات IP وأجهزة التسجيل DVR/NVR ومراقبات الأطفال على هذه الشبكة عبر اكتشاف ONVIF ومنافذ الفيديو (RTSP وغيره) وأسماء الشركات والأجهزة. لا يحاول تسجيل الدخول أبداً. الكاميرات التي تسجّل محلياً أو تعمل بالبيانات لن تظهر هنا."),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Button(enabled = !busy && info != null, onClick = {
        busy = true
        found = emptyList()
        scope.launch {
            val list = Collections.synchronizedList(mutableListOf<Device>())
            Net.scan(ctx, info!!) { if (it.kind == "camera") list.add(it) }
            found = list.toList().sortedBy { Net.ipToLong(it.ip) }
            scanned = true
            busy = false
        }
    }) { Text(t("Scan for cameras", "ابحث عن الكاميرات")) }
    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
    if (scanned && found.isEmpty()) Text(t("No cameras found on this network.", "لم يُعثر على كاميرات في هذه الشبكة."))
    for (d in found) {
        ListItem(
            overlineContent = { Text("📷 " + t("Camera / recorder", "كاميرا / مسجّل")) },
            headlineContent = { Text(d.host.ifBlank { d.ip }) },
            supportingContent = { Text((d.ip + " · " + d.vendor + "\n" + d.info).trim()) },
            trailingContent = {
                TextButton(onClick = {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("http://" + d.ip)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }) { Text(t("Open", "فتح")) }
            }
        )
    }
}

// ---------------- File sharing ----------------

@Composable
fun ShareTool(info: NetInfo?) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var receive by remember { mutableStateOf(false) }
    var peers by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var pending by remember { mutableStateOf<Incoming?>(null) }
    var received by remember { mutableStateOf<List<String>>(emptyList()) }
    var target by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var progress by remember { mutableFloatStateOf(0f) }
    var sending by remember { mutableStateOf(false) }
    DisposableEffect(Unit) { onDispose { Share.stop() } }
    LaunchedEffect(Unit) {
        while (true) {
            peers = HashMap(Share.peers)
            pending = Share.pending
            received = Share.received.toList()
            delay(800)
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty() && target.isNotBlank()) {
            sending = true
            scope.launch {
                for (u in uris) {
                    progress = 0f
                    status = try {
                        t("Sent: ", "أُرسل: ") + Share.send(ctx, target.trim(), u) { progress = it }
                    } catch (e: Exception) { "✖ " + (e.message ?: "error") }
                }
                sending = false
            }
        }
    }
    Text(
        t("Send files to another phone or computer running NetScout on the same Wi-Fi. The receiver must turn on Receive mode and accept every file. Files are not encrypted on the local network.",
            "أرسل ملفات إلى هاتف آخر يشغّل NetScout على نفس الواي فاي. على المستقبِل تفعيل وضع الاستقبال وقبول كل ملف. الملفات غير مشفّرة داخل الشبكة المحلية."),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(t("Receive mode", "وضع الاستقبال"), Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
        Switch(receive, { receive = it; if (it) Share.start(ctx, info) else Share.stop() })
    }
    Text(t("Nearby devices", "الأجهزة القريبة"), style = MaterialTheme.typography.titleSmall)
    if (peers.isEmpty()) Text(t("None found. Ask the other device to turn on Receive mode, or type its IP below.", "لا يوجد. اطلب من الجهاز الآخر تفعيل وضع الاستقبال، أو اكتب عنوان IP أدناه."),
        style = MaterialTheme.typography.bodySmall)
    for ((ip, name) in peers) {
        ListItem(
            headlineContent = { Text(name) },
            supportingContent = { Text(ip) },
            trailingContent = { RadioButton(target == ip, { target = ip }) },
            modifier = Modifier.clickable { target = ip }
        )
    }
    OutlinedTextField(target, { target = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(t("Receiver IP", "عنوان IP للمستقبِل")) })
    Button(enabled = target.isNotBlank() && !sending, onClick = { picker.launch("*/*") }) { Text(t("Choose files and send", "اختر الملفات وأرسل")) }
    if (sending) LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
    if (status.isNotEmpty()) Text(status)
    if (received.isNotEmpty()) {
        Text(t("Received files", "الملفات المستلمة"), style = MaterialTheme.typography.titleSmall)
        for (p in received.take(20)) {
            val f = File(p)
            ListItem(
                headlineContent = { Text(f.name) },
                supportingContent = { Text(fmtBytes(f.length())) },
                trailingContent = {
                    TextButton(onClick = {
                        try {
                            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
                            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
                            ctx.startActivity(
                                Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } catch (e: Exception) { }
                    }) { Text(t("Open", "فتح")) }
                }
            )
        }
    }
    pending?.let { inc ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text(t("Incoming file", "ملف وارد")) },
            text = { Text(inc.from + "\n" + inc.name + " (" + fmtBytes(inc.size) + ")") },
            confirmButton = { TextButton(onClick = { inc.decision.complete(true) }) { Text(t("Accept", "قبول")) } },
            dismissButton = { TextButton(onClick = { inc.decision.complete(false) }) { Text(t("Decline", "رفض")) } }
        )
    }
}
