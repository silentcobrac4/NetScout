package com.amir.netscout

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.Collections
import java.util.concurrent.TimeUnit

class MonitorWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result {
        val c = applicationContext
        Store.init(c)
        val info = Net.info(c) ?: return Result.success()
        val found = Collections.synchronizedList(mutableListOf<Device>())
        Net.scan(c, info) { found.add(it) }
        val list = found.toList()
        Store.setLast(list.size)
        val fresh = Store.record(list)
        NetWidget.updateAll(c)
        if (fresh.isNotEmpty()) Monitor.notifyFresh(c, fresh)
        return Result.success()
    }
}

object Monitor {
    fun notifyFresh(c: Context, fresh: List<Device>) {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("alerts", "Network alerts", NotificationManager.IMPORTANCE_HIGH))
        val text = fresh.joinToString { (if (it.kind == "camera") "📷 " else "") + it.host.ifBlank { it.ip } + " (" + it.ip + ")" }
        val n = Notification.Builder(c, "alerts")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(t("Unknown device on your network", "جهاز غير معروف على شبكتك"))
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .build()
        nm.notify(1001, n)
    }

    fun schedule(ctx: Context, minutes: Int) {
        val wm = WorkManager.getInstance(ctx.applicationContext)
        if (minutes <= 0) {
            wm.cancelUniqueWork("monitor")
        } else {
            val req = PeriodicWorkRequestBuilder<MonitorWorker>(maxOf(minutes, 15).toLong(), TimeUnit.MINUTES).build()
            wm.enqueueUniquePeriodicWork("monitor", ExistingPeriodicWorkPolicy.UPDATE, req)
        }
    }
}
