package com.amir.netscout

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Builds a self-contained, shareable HTML report of the network. */
object Dashboard {
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
    private fun hex(c: Color) = String.format(Locale.US, "#%06X", 0xFFFFFF and c.toArgb())

    private fun grid(m: Map<Int, Int>, speed: Boolean): String {
        if (m.isEmpty()) return "<p>-</p>"
        val mx = maxOf((m.values.maxOrNull() ?: 1) / 10.0, 10.0)
        val sb = StringBuilder("<div class=\"g\">")
        for (i in 0 until 80) {
            val v = m[i]
            if (v == null) { sb.append("<i></i>"); continue }
            val col = if (speed) hex(heatColor(-90.0 + 50.0 * ((v / 10.0) / mx).coerceIn(0.0, 1.0))) else hex(heatColor(v.toDouble()))
            val txt = if (speed) String.format(Locale.US, "%.0f", v / 10.0) else v.toString()
            sb.append("<i style=\"background:$col\">$txt</i>")
        }
        return sb.append("</div>").toString()
    }

    private fun chart(): String {
        val pts = Store.speeds.takeLast(30)
        if (pts.size < 2) return "<p>-</p>"
        val mx = maxOf(pts.maxOf { maxOf(it.down, it.up) }, 1.0)
        fun poly(sel: (SpeedRec) -> Double, color: String): String {
            val p = pts.mapIndexed { i, r ->
                String.format(Locale.US, "%.1f,%.1f", i * 600.0 / (pts.size - 1), 150 - maxOf(sel(r), 0.0) / mx * 140)
            }.joinToString(" ")
            return "<polyline fill=\"none\" stroke=\"$color\" stroke-width=\"2\" points=\"$p\"/>"
        }
        return "<svg viewBox=\"0 0 600 160\" width=\"100%\">" + poly({ it.down }, "#1e88e5") + poly({ it.up }, "#fb8c00") +
            "</svg><small>" + t("Blue: download, orange: upload (max ", "الأزرق: تحميل، البرتقالي: رفع (الأعلى ") +
            String.format(Locale.US, "%.0f", mx) + " Mbps)</small>"
    }

    fun build(ctx: Context, ds: List<Device>, info: NetInfo?): String {
        val rtl = Locale.getDefault().language == "ar"
        val f = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        val base = Store.baseline()
        val sorted = ds.sortedBy { Net.ipToLong(it.ip) }
        val cams = sorted.count { it.kind == "camera" }
        val unknown = sorted.count { base && !Store.metaFor(it).trusted && !it.isSelf && !it.isGateway }
        val key = info?.ssid ?: "—"
        val sb = StringBuilder()
        sb.append("<!doctype html><html lang=\"" + (if (rtl) "ar" else "en") + "\" dir=\"" + (if (rtl) "rtl" else "ltr") + "\"><head>")
        sb.append("<meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>NetScout</title><style>")
        sb.append(":root{color-scheme:light dark;--bg:#fff;--fg:#111;--card:#f2f4f8;--line:#d8dce3}")
        sb.append("@media(prefers-color-scheme:dark){:root{--bg:#10141a;--fg:#eee;--card:#1b222c;--line:#2d3744}}")
        sb.append("body{margin:0;padding:16px;font-family:system-ui,sans-serif;background:var(--bg);color:var(--fg)}")
        sb.append("h1{margin:0 0 4px}h2{margin:24px 0 8px}.c{display:flex;gap:8px;flex-wrap:wrap}")
        sb.append(".k{background:var(--card);border-radius:12px;padding:12px 16px;min-width:110px}.k b{display:block;font-size:24px}")
        sb.append("table{border-collapse:collapse;width:100%}td,th{padding:6px 8px;border-bottom:1px solid var(--line);text-align:start;font-size:14px}")
        sb.append(".wrap{overflow-x:auto}.g{display:grid;grid-template-columns:repeat(8,1fr);gap:2px;max-width:320px}")
        sb.append(".g i{aspect-ratio:1;border:1px solid var(--line);font-size:10px;font-style:normal;display:flex;align-items:center;justify-content:center;color:#000}")
        sb.append("</style></head><body>")
        sb.append("<h1>NetScout</h1><small>" + f.format(Date()) + " · " + esc(key) + "</small>")
        sb.append("<div class=\"c\" style=\"margin-top:12px\">")
        sb.append("<div class=\"k\"><b>" + sorted.size + "</b>" + t("Devices", "الأجهزة") + "</div>")
        sb.append("<div class=\"k\"><b>" + cams + "</b>" + t("Cameras", "كاميرات") + "</div>")
        sb.append("<div class=\"k\"><b>" + (if (base) unknown.toString() else "-") + "</b>" + t("Unknown", "غير معروف") + "</div>")
        sb.append("<div class=\"k\"><b>" + (if (Store.lastDown >= 0) String.format(Locale.US, "%.0f", Store.lastDown) else "-") + "</b>Mbps</div></div>")
        sb.append("<h2>" + t("Devices", "الأجهزة") + "</h2><div class=\"wrap\"><table><tr><th>IP</th><th>" + t("Name", "الاسم") +
            "</th><th>" + t("Vendor", "الشركة") + "</th><th>" + t("Type", "النوع") + "</th><th>ms</th><th></th></tr>")
        for (d in sorted) {
            val m = Store.metaFor(d)
            val name = m.nick.ifBlank { d.host }
            val st = when {
                d.isSelf -> t("This device", "هذا الجهاز")
                d.isGateway -> t("Router", "الراوتر")
                d.kind == "camera" -> "📷"
                base && !m.trusted -> "⚠"
                else -> ""
            }
            sb.append("<tr><td>" + esc(d.ip) + "</td><td>" + esc(name) + "</td><td>" + esc(d.vendor) + "</td><td>" +
                esc(kindLabel(d.kind)) + "</td><td>" + d.pingMs + "</td><td>" + st + "</td></tr>")
        }
        sb.append("</table></div>")
        sb.append("<h2>" + t("Internet speed history", "سجل سرعة الإنترنت") + "</h2>" + chart())
        sb.append("<h2>" + t("Signal map", "خريطة الإشارة") + "</h2>" + grid(Store.heat[key] ?: emptyMap(), false))
        sb.append("<h2>" + t("Speed map (Mbps)", "خريطة السرعة (Mbps)") + "</h2>" + grid(Store.heatSpeed[key] ?: emptyMap(), true))
        val blocked = FirewallStore.blocked(ctx)
        if (blocked.isNotEmpty()) {
            sb.append("<h2>" + t("Firewall: blocked apps", "الجدار الناري: التطبيقات المحجوبة") + "</h2><ul>")
            for (p in blocked.sorted()) sb.append("<li>" + esc(p) + "</li>")
            sb.append("</ul>")
        }
        sb.append("<p><small>NetScout</small></p></body></html>")
        return sb.toString()
    }

    fun file(ctx: Context, ds: List<Device>, info: NetInfo?): File =
        File(ctx.cacheDir, "netscout-dashboard.html").also { it.writeText(build(ctx, ds, info)) }
}
