package com.amir.netscout

import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.*
import java.security.KeyStore
import java.security.cert.X509Certificate
import java.util.concurrent.ConcurrentHashMap
import javax.net.ssl.*
import kotlin.math.abs
import java.util.concurrent.TimeUnit

data class Ap(val ssid: String, val bssid: String, val level: Int, val freq: Int, val sec: String) {
    val channel: Int
        get() = when {
            freq in 2412..2484 -> (freq - 2407) / 5
            freq in 5000..5900 -> (freq - 5000) / 5
            freq >= 5955 -> (freq - 5950) / 5
            else -> 0
        }
}

data class Ble(val name: String, val addr: String, val rssi: Int)

object Tools {
    private suspend fun run(cmd: List<String>, timeoutMs: Long = 20000): String = withContext(Dispatchers.IO) {
        try {
            val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
            val out = StringBuilder()
            val th = Thread {
                try { p.inputStream.bufferedReader().forEachLine { out.appendLine(it) } } catch (e: Exception) { }
            }
            th.start()
            if (!p.waitFor(timeoutMs, TimeUnit.MILLISECONDS)) p.destroy()
            th.join(500)
            out.toString().trim()
        } catch (e: Exception) { "" }
    }

    suspend fun ping(host: String): String {
        val o = run(listOf("/system/bin/ping", "-c", "4", "-W", "2", host))
        if (o.isNotEmpty()) return o
        val ms = Net.tcpLatency(host, 443)
        return "TCP 443: " + if (ms >= 0) "$ms ms" else "timeout"
    }

    suspend fun trace(host: String, emit: suspend (String) -> Unit) {
        for (ttl in 1..30) {
            val t0 = System.nanoTime()
            val o = run(listOf("/system/bin/ping", "-c", "1", "-W", "1", "-t", ttl.toString(), host), 5000)
            val ms = (System.nanoTime() - t0) / 1_000_000
            val ip = Regex("(?i)from (\\d+\\.\\d+\\.\\d+\\.\\d+)").find(o)?.groupValues?.get(1)
            emit("$ttl   " + (ip ?: "*") + (if (ip != null) "   ~$ms ms" else ""))
            if (o.contains("bytes from", true) && !o.contains("exceeded", true)) break
        }
    }

    suspend fun dns(host: String, type: String): String = withContext(Dispatchers.IO) {
        try {
            val c = URL("https://cloudflare-dns.com/dns-query?name=" + URLEncoder.encode(host, "UTF-8") + "&type=" + type)
                .openConnection() as HttpURLConnection
            c.setRequestProperty("accept", "application/dns-json")
            c.connectTimeout = 5000; c.readTimeout = 5000
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            val a = j.optJSONArray("Answer")
            if (a == null) "No records (status ${j.optInt("Status")})"
            else (0 until a.length()).joinToString("\n") { a.getJSONObject(it).optString("data") }
        } catch (e: Exception) { "Error: ${e.message}" }
    }

    private fun whoisQ(server: String, q: String): String =
        Socket().use { s ->
            s.connect(InetSocketAddress(server, 43), 5000)
            s.soTimeout = 8000
            s.getOutputStream().write((q + "\r\n").toByteArray())
            s.getOutputStream().flush()
            s.getInputStream().bufferedReader().readText()
        }

    suspend fun whois(q: String): String = withContext(Dispatchers.IO) {
        try {
            val first = whoisQ("whois.iana.org", q)
            val ref = Regex("(?im)^(?:refer|whois):\\s*(\\S+)").find(first)?.groupValues?.get(1)
            val r = if (ref != null) whoisQ(ref, q) else first
            r.lines().filter { it.isNotBlank() && !it.startsWith("%") && !it.startsWith("#") }
                .take(60).joinToString("\n")
        } catch (e: Exception) { "Error: ${e.message}" }
    }

    fun parsePorts(s: String): List<Int> = s.split(",").flatMap { part ->
        val r = part.trim().split("-")
        try {
            if (r.size == 2) (r[0].trim().toInt()..r[1].trim().toInt()).toList() else listOf(r[0].trim().toInt())
        } catch (e: Exception) { emptyList() }
    }.filter { it in 1..65535 }.distinct().take(20000)

    suspend fun scanPorts(host: String, ports: List<Int>): List<Int> = coroutineScope {
        val addr = withContext(Dispatchers.IO) { InetAddress.getByName(host) }
        val sem = Semaphore(300)
        ports.map { p ->
            async(Dispatchers.IO) {
                sem.withPermit {
                    try {
                        Socket().use { it.connect(InetSocketAddress(addr, p), 300) }
                        p
                    } catch (e: Exception) { -1 }
                }
            }
        }.awaitAll().filter { it > 0 }
    }

    suspend fun wol(mac: String, broadcast: String): String = withContext(Dispatchers.IO) {
        try {
            val m = mac.trim().split(":", "-").map { it.trim().toInt(16).toByte() }
            require(m.size == 6)
            val pkt = ByteArray(6) { 0xFF.toByte() } + (1..16).flatMap { m }.toByteArray()
            DatagramSocket().use { s ->
                s.broadcast = true
                for (b in listOf(broadcast, "255.255.255.255")) for (port in intArrayOf(9, 7))
                    s.send(DatagramPacket(pkt, pkt.size, InetAddress.getByName(b), port))
            }
            "Magic packet sent to $mac"
        } catch (e: Exception) { "Error: invalid MAC address or no network" }
    }

    suspend fun http(url: String): String = withContext(Dispatchers.IO) {
        try {
            val u = if (url.startsWith("http")) url else "http://$url"
            val t = System.nanoTime()
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 5000; c.readTimeout = 5000; c.instanceFollowRedirects = false
            val code = c.responseCode
            val ms = (System.nanoTime() - t) / 1_000_000
            "HTTP $code ${c.responseMessage ?: ""}\n$ms ms\nServer: ${c.getHeaderField("Server") ?: "-"}\nLocation: ${c.getHeaderField("Location") ?: "-"}"
        } catch (e: Exception) { "Error: ${e.message}" }
    }

    suspend fun routerCheck(ctx: Context, info: NetInfo?): String {
        if (info == null || info.gateway.isEmpty()) return "Not connected"
        val open = Net.portScan(info.gateway)
        val upnp = withContext(Dispatchers.IO) { Net.ssdp(ctx, 1500) }.containsKey(info.gateway)
        val risky = mapOf(
            23 to "Telnet is open: disable it", 21 to "FTP is open: disable it",
            7547 to "TR-069 (ISP management) reachable from LAN", 139 to "NetBIOS exposed",
            445 to "SMB exposed", 3389 to "Remote Desktop exposed"
        )
        val sb = StringBuilder("Router ${info.gateway}\nOpen ports: ")
        sb.append(if (open.isEmpty()) "none" else open.joinToString { "${it.first}/${it.second}" }).append("\n\n")
        for ((p, _) in open) risky[p]?.let { sb.append("⚠ $it\n") }
        if (upnp) sb.append("⚠ UPnP answers on the LAN: disable it if unused\n")
        if (open.any { it.first == 80 } && open.none { it.first == 443 }) sb.append("⚠ Admin page is HTTP only\n")
        sb.append("\nTips: change the default admin password, use WPA2/WPA3, update the firmware.")
        return sb.toString()
    }

    @Suppress("DEPRECATION")
    @SuppressLint("MissingPermission")
    fun wifiScan(ctx: Context): List<Ap> = try {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        try { wm.startScan() } catch (e: Exception) { }
        wm.scanResults.map { r ->
            val c = r.capabilities ?: ""
            Ap(
                r.SSID ?: "", r.BSSID ?: "", r.level, r.frequency,
                when {
                    c.contains("WPA3") || c.contains("SAE") -> "WPA3"
                    c.contains("WPA2") -> "WPA2"
                    c.contains("WPA") -> "WPA"
                    c.contains("WEP") -> "WEP (weak)"
                    else -> "Open"
                }
            )
        }.sortedByDescending { it.level }
    } catch (e: Exception) { emptyList() }

    @SuppressLint("MissingPermission")
    suspend fun bleScan(ctx: Context): List<Ble> {
        val bm = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val sc = bm.adapter?.bluetoothLeScanner ?: return emptyList()
        val found = ConcurrentHashMap<String, Ble>()
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                found[result.device.address] = Ble(result.scanRecord?.deviceName ?: "", result.device.address, result.rssi)
            }
        }
        try {
            sc.startScan(cb)
            delay(8000)
        } catch (e: Exception) {
        } finally {
            try { sc.stopScan(cb) } catch (e: Exception) { }
        }
        return found.values.sortedByDescending { it.rssi }
    }

    suspend fun upMbps(): Double = withContext(Dispatchers.IO) {
        try {
            val size = 8_000_000
            val c = URL("https://speed.cloudflare.com/__up").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true
            c.setFixedLengthStreamingMode(size)
            c.connectTimeout = 5000; c.readTimeout = 15000
            val buf = ByteArray(65536)
            val s = System.nanoTime()
            c.outputStream.use { o ->
                var sent = 0
                while (sent < size) {
                    val n = minOf(buf.size, size - sent)
                    o.write(buf, 0, n)
                    sent += n
                }
            }
            c.responseCode
            size * 8 / 1e6 / ((System.nanoTime() - s) / 1e9)
        } catch (e: Exception) { -1.0 }
    }

    // ---------------- new tools ----------------

    private fun ipType(ip: Long): String = when {
        (ip shr 24) == 10L -> "Private (10.0.0.0/8)"
        (ip shr 20) == 0xAC1L -> "Private (172.16.0.0/12)"
        (ip shr 16) == 0xC0A8L -> "Private (192.168.0.0/16)"
        (ip shr 24) == 127L -> "Loopback"
        (ip shr 16) == 0xA9FEL -> "Link-local (169.254.0.0/16)"
        (ip shr 22) == 0x191L -> "CGNAT (100.64.0.0/10)"
        else -> "Public"
    }

    fun subnet(cidr: String): String = try {
        val parts = cidr.trim().split("/")
        val p = parts[1].trim().toInt()
        require(p in 0..32)
        val ip = Net.ipToLong(parts[0].trim())
        val mask = if (p == 0) 0L else (0xFFFFFFFFL shl (32 - p)) and 0xFFFFFFFFL
        val net = ip and mask
        val bc = net or (mask.inv() and 0xFFFFFFFFL)
        val two = p >= 31
        val hosts = if (two) (1L shl (32 - p)) else (1L shl (32 - p)) - 2
        "Network:   ${Net.longToIp(net)}/$p\nMask:      ${Net.longToIp(mask)}\n" +
            "Wildcard:  ${Net.longToIp(mask.inv() and 0xFFFFFFFFL)}\nBroadcast: ${Net.longToIp(bc)}\n" +
            "First:     ${Net.longToIp(if (two) net else net + 1)}\nLast:      ${Net.longToIp(if (two) bc else bc - 1)}\n" +
            "Hosts:     $hosts\nType:      ${ipType(ip)}"
    } catch (e: Exception) { "Enter like 192.168.1.10/24" }

    suspend fun ssl(host: String): String = withContext(Dispatchers.IO) {
        try {
            val h = host.trim().removePrefix("https://").substringBefore("/").substringBefore(":")
            val trustAll = object : X509TrustManager {
                override fun checkClientTrusted(c: Array<X509Certificate>?, a: String?) {}
                override fun checkServerTrusted(c: Array<X509Certificate>?, a: String?) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            }
            val sc = SSLContext.getInstance("TLS")
            sc.init(null, arrayOf<TrustManager>(trustAll), null)
            val raw = sc.socketFactory.createSocket() as SSLSocket
            raw.use { sock ->
                sock.connect(InetSocketAddress(h, 443), 5000)
                sock.soTimeout = 5000
                if (!h.matches(Regex("[0-9.]+"))) {
                    val params = sock.sslParameters
                    params.serverNames = listOf(SNIHostName(h))
                    sock.sslParameters = params
                }
                sock.startHandshake()
                val chain = sock.session.peerCertificates.map { it as X509Certificate }
                val c = chain[0]
                val tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
                tmf.init(null as KeyStore?)
                val tm = tmf.trustManagers.filterIsInstance<X509TrustManager>().first()
                val alg = c.publicKey.algorithm.let { if (it == "EC") "ECDSA" else it }
                val trusted = try { tm.checkServerTrusted(chain.toTypedArray(), alg); true } catch (e: Exception) { false }
                val days = (c.notAfter.time - System.currentTimeMillis()) / 86_400_000L
                val san = try {
                    c.subjectAlternativeNames?.mapNotNull { it.getOrNull(1)?.toString() }?.take(8)?.joinToString(", ") ?: "-"
                } catch (e: Exception) { "-" }
                "Subject: ${c.subjectX500Principal.name}\nIssuer: ${c.issuerX500Principal.name}\n" +
                    "Valid: ${c.notBefore} -> ${c.notAfter}\nDays left: $days" + (if (days < 0) "  (EXPIRED)" else if (days < 14) "  (expires soon)" else "") + "\n" +
                    "Trusted by system: " + (if (trusted) "yes" else "NO") + "\n" +
                    "Names: $san\nProtocol: ${sock.session.protocol}\nCipher: ${sock.session.cipherSuite}\nChain length: ${chain.size}"
            }
        } catch (e: Exception) { "Error: ${e.message}" }
    }

    suspend fun banner(host: String, port: Int): String = withContext(Dispatchers.IO) {
        try {
            Socket().use { s ->
                s.connect(InetSocketAddress(host.trim(), port), 4000)
                s.soTimeout = 3000
                if (port == 80 || port == 8080 || port == 8000 || port == 8008) {
                    s.getOutputStream().write("HEAD / HTTP/1.0\r\nHost: ${host.trim()}\r\n\r\n".toByteArray())
                }
                val buf = ByteArray(1024)
                val n = try { s.getInputStream().read(buf) } catch (e: SocketTimeoutException) { -1 }
                if (n > 0) String(buf, 0, n).replace(Regex("[^\\x20-\\x7E\\r\\n]"), ".").trim()
                else "Port $port is open, no banner received"
            }
        } catch (e: Exception) { "Error: ${e.message}" }
    }

    private fun udpDns(server: String, name: String): Long {
        val bo = ByteArrayOutputStream()
        bo.write(byteArrayOf(0x12, 0x34, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0))
        for (l in name.split(".")) { bo.write(l.length); bo.write(l.toByteArray()) }
        bo.write(0)
        bo.write(byteArrayOf(0, 1, 0, 1))
        val q = bo.toByteArray()
        return try {
            DatagramSocket().use { s ->
                s.soTimeout = 1500
                val t0 = System.nanoTime()
                s.send(DatagramPacket(q, q.size, InetAddress.getByName(server), 53))
                val b = ByteArray(512)
                s.receive(DatagramPacket(b, b.size))
                (System.nanoTime() - t0) / 1_000_000
            }
        } catch (e: Exception) { -1L }
    }

    suspend fun dnsBench(info: NetInfo?): String = withContext(Dispatchers.IO) {
        val servers = linkedMapOf("Cloudflare" to "1.1.1.1", "Google" to "8.8.8.8", "Quad9" to "9.9.9.9", "OpenDNS" to "208.67.222.222")
        info?.dns?.split(",")?.map { it.trim() }?.filter { it.matches(Regex("\\d+\\.\\d+\\.\\d+\\.\\d+")) }
            ?.forEachIndexed { i, ip -> servers["Current #${i + 1}"] = ip }
        val names = listOf("google.com", "wikipedia.org", "cloudflare.com", "amazon.com", "github.com")
        val rows = servers.map { (n, ip) ->
            val r = names.map { udpDns(ip, it) }.filter { it >= 0 }
            Triple(n, ip, if (r.isEmpty()) -1L else r.sum() / r.size)
        }.sortedBy { if (it.third < 0) Long.MAX_VALUE else it.third }
        rows.joinToString("\n") { (n, ip, ms) -> n.padEnd(14) + ip.padEnd(17) + (if (ms >= 0) "$ms ms" else "no reply") } +
            "\n\nFastest: " + (rows.firstOrNull { it.third >= 0 }?.first ?: "-")
    }

    fun channelAdvice(ctx: Context): String {
        val aps = wifiScan(ctx)
        if (aps.isEmpty()) return "No scan results. Turn on Location, allow the permission, then retry."
        val g24 = aps.filter { it.freq in 2412..2484 }
        val score = (1..13).associateWith { ch ->
            g24.sumOf { a ->
                val d = abs(a.channel - ch)
                if (d <= 4) ((a.level + 100).coerceAtLeast(1) * (5 - d)).toLong() else 0L
            }
        }
        val best = listOf(1, 6, 11).minByOrNull { score[it] ?: 0L }
        val sb = StringBuilder("2.4 GHz networks: ${g24.size}\n")
        for (ch in listOf(1, 6, 11)) sb.append("  channel $ch: interference ${score[ch]}\n")
        sb.append("Best 2.4 GHz channel: $best\n\n")
        val g5 = aps.filter { it.freq >= 4900 }
        sb.append("5 GHz networks: ${g5.size}\n")
        g5.groupBy { it.channel }.toSortedMap().forEach { (c, l) -> sb.append("  ch$c: ${l.size}\n") }
        sb.append("\nTip: set your router to the best channel manually and prefer 5 GHz for speed.")
        return sb.toString()
    }

    suspend fun ipLookup(ip: String): String = withContext(Dispatchers.IO) {
        try {
            val u = if (ip.isBlank()) "https://ipinfo.io/json" else "https://ipinfo.io/" + URLEncoder.encode(ip.trim(), "UTF-8") + "/json"
            val j = JSONObject(URL(u).readText())
            listOf("ip", "hostname", "org", "city", "region", "country", "loc", "timezone")
                .mapNotNull { k -> j.optString(k).takeIf { it.isNotEmpty() }?.let { "$k: $it" } }
                .joinToString("\n").ifEmpty { "No data" }
        } catch (e: Exception) { "Error: ${e.message}" }
    }

    @Suppress("DEPRECATION")
    suspend fun sampleRssi(ctx: Context): Int? = withContext(Dispatchers.IO) {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val v = mutableListOf<Int>()
        repeat(5) {
            val r = wm.connectionInfo?.rssi ?: -127
            if (r > -127) v.add(r)
            delay(400)
        }
        if (v.isEmpty()) null else v.sum() / v.size
    }

    suspend fun publicIp(): String = withContext(Dispatchers.IO) {
        try {
            val j = JSONObject(URL("https://ipinfo.io/json").readText())
            "${j.optString("ip")} · ${j.optString("org")} · ${j.optString("city")}, ${j.optString("country")}"
        } catch (e: Exception) { "—" }
    }
}
