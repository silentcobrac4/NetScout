package com.amir.netscout

import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.json.JSONObject
import java.net.*
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

data class Ap(val ssid: String, val bssid: String, val level: Int, val freq: Int, val sec: String) {
    val channel: Int
        get() = when {
            freq in 2412..2484 -> (freq - 2407) / 5
            freq in 5000..5900 -> (freq - 5000) / 5
            freq >= 5955 -> (freq - 5950) / 5
            else -> 0
        }
}

data class Ble(val name: String, val addr: String, val rssi: Int)

object Tools {
    private suspend fun run(cmd: List<String>, timeoutMs: Long = 20000): String = withContext(Dispatchers.IO) {
        try {
            val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
            val out = StringBuilder()
            val th = Thread {
                try { p.inputStream.bufferedReader().forEachLine { out.appendLine(it) } } catch (e: Exception) { }
            }
            th.start()
            if (!p.waitFor(timeoutMs, TimeUnit.MILLISECONDS)) p.destroy()
            th.join(500)
            out.toString().trim()
        } catch (e: Exception) { "" }
    }

    suspend fun ping(host: String): String {
        val o = run(listOf("/system/bin/ping", "-c", "4", "-W", "2", host))
        if (o.isNotEmpty()) return o
        val ms = Net.tcpLatency(host, 443)
        return "TCP 443: " + if (ms >= 0) "$ms ms" else "timeout"
    }

    suspend fun trace(host: String, emit: suspend (String) -> Unit) {
        for (ttl in 1..30) {
            val t0 = System.nanoTime()
            val o = run(listOf("/system/bin/ping", "-c", "1", "-W", "1", "-t", ttl.toString(), host), 5000)
            val ms = (System.nanoTime() - t0) / 1_000_000
            val ip = Regex("(?i)from (\\d+\\.\\d+\\.\\d+\\.\\d+)").find(o)?.groupValues?.get(1)
            emit("$ttl   " + (ip ?: "*") + (if (ip != null) "   ~$ms ms" else ""))
            if (o.contains("bytes from", true) && !o.contains("exceeded", true)) break
        }
    }

    suspend fun dns(host: String, type: String): String = withContext(Dispatchers.IO) {
        try {
            val c = URL("https://cloudflare-dns.com/dns-query?name=" + URLEncoder.encode(host, "UTF-8") + "&type=" + type)
                .openConnection() as HttpURLConnection
            c.setRequestProperty("accept", "application/dns-json")
            c.connectTimeout = 5000; c.readTimeout = 5000
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            val a = j.optJSONArray("Answer")
            if (a == null) "No records (status ${j.optInt("Status")})"
            else (0 until a.length()).joinToString("\n") { a.getJSONObject(it).optString("data") }
        } catch (e: Exception) { "Error: ${e.message}" }
    }

    private fun whoisQ(server: String, q: String): String =
        Socket().use { s ->
            s.connect(InetSocketAddress(server, 43), 5000)
            s.soTimeout = 8000
            s.getOutputStream().write((q + "\r\n").toByteArray())
            s.getOutputStream().flush()
            s.getInputStream().bufferedReader().readText()
        }

    suspend fun whois(q: String): String = withContext(Dispatchers.IO) {
        try {
            val first = whoisQ("whois.iana.org", q)
            val ref = Regex("(?im)^(?:refer|whois):\\s*(\\S+)").find(first)?.groupValues?.get(1)
            val r = if (ref != null) whoisQ(ref, q) else first
            r.lines().filter { it.isNotBlank() && !it.startsWith("%") && !it.startsWith("#") }
                .take(60).joinToString("\n")
        } catch (e: Exception) { "Error: ${e.message}" }
    }

    fun parsePorts(s: String): List<Int> = s.split(",").flatMap { part ->
        val r = part.trim().split("-")
        try {
            if (r.size == 2) (r[0].trim().toInt()..r[1].trim().toInt()).toList() else listOf(r[0].trim().toInt())
        } catch (e: Exception) { emptyList() }
    }.filter { it in 1..65535 }.distinct().take(20000)

    suspend fun scanPorts(host: String, ports: List<Int>): List<Int> = coroutineScope {
        val addr = withContext(Dispatchers.IO) { InetAddress.getByName(host) }
        val sem = Semaphore(300)
        ports.map { p ->
            async(Dispatchers.IO) {
                sem.withPermit {
                    try {
                        Socket().use { it.connect(InetSocketAddress(addr, p), 300) }
                        p
                    } catch (e: Exception) { -1 }
                }
            }
        }.awaitAll().filter { it > 0 }
    }

    suspend fun wol(mac: String, broadcast: String): String = withContext(Dispatchers.IO) {
        try {
            val m = mac.trim().split(":", "-").map { it.trim().toInt(16).toByte() }
            require(m.size == 6)
            val pkt = ByteArray(6) { 0xFF.toByte() } + (1..16).flatMap { m }.toByteArray()
            DatagramSocket().use { s ->
                s.broadcast = true
                for (b in listOf(broadcast, "255.255.255.255")) for (port in intArrayOf(9, 7))
                    s.send(DatagramPacket(pkt, pkt.size, InetAddress.getByName(b), port))
            }
            "Magic packet sent to $mac"
        } catch (e: Exception) { "Error: invalid MAC address or no network" }
    }

    suspend fun http(url: String): String = withContext(Dispatchers.IO) {
        try {
            val u = if (url.startsWith("http")) url else "http://$url"
            val t = System.nanoTime()
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 5000; c.readTimeout = 5000; c.instanceFollowRedirects = false
            val code = c.responseCode
            val ms = (System.nanoTime() - t) / 1_000_000
            "HTTP $code ${c.responseMessage ?: ""}\n$ms ms\nServer: ${c.getHeaderField("Server") ?: "-"}\nLocation: ${c.getHeaderField("Location") ?: "-"}"
        } catch (e: Exception) { "Error: ${e.message}" }
    }

    suspend fun routerCheck(ctx: Context, info: NetInfo?): String {
        if (info == null || info.gateway.isEmpty()) return "Not connected"
        val open = Net.portScan(info.gateway)
        val upnp = withContext(Dispatchers.IO) { Net.ssdp(ctx, 1500) }.containsKey(info.gateway)
        val risky = mapOf(
            23 to "Telnet is open: disable it", 21 to "FTP is open: disable it",
            7547 to "TR-069 (ISP management) reachable from LAN", 139 to "NetBIOS exposed",
            445 to "SMB exposed", 3389 to "Remote Desktop exposed"
        )
        val sb = StringBuilder("Router ${info.gateway}\nOpen ports: ")
        sb.append(if (open.isEmpty()) "none" else open.joinToString { "${it.first}/${it.second}" }).append("\n\n")
        for ((p, _) in open) risky[p]?.let { sb.append("⚠ $it\n") }
        if (upnp) sb.append("⚠ UPnP answers on the LAN: disable it if unused\n")
        if (open.any { it.first == 80 } && open.none { it.first == 443 }) sb.append("⚠ Admin page is HTTP only\n")
        sb.append("\nTips: change the default admin password, use WPA2/WPA3, update the firmware.")
        return sb.toString()
    }

    @Suppress("DEPRECATION")
    @SuppressLint("MissingPermission")
    fun wifiScan(ctx: Context): List<Ap> = try {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        try { wm.startScan() } catch (e: Exception) { }
        wm.scanResults.map { r ->
            val c = r.capabilities ?: ""
            Ap(
                r.SSID ?: "", r.BSSID ?: "", r.level, r.frequency,
                when {
                    c.contains("WPA3") || c.contains("SAE") -> "WPA3"
                    c.contains("WPA2") -> "WPA2"
                    c.contains("WPA") -> "WPA"
                    c.contains("WEP") -> "WEP (weak)"
                    else -> "Open"
                }
            )
        }.sortedByDescending { it.level }
    } catch (e: Exception) { emptyList() }

    @SuppressLint("MissingPermission")
    suspend fun bleScan(ctx: Context): List<Ble> {
        val bm = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val sc = bm.adapter?.bluetoothLeScanner ?: return emptyList()
        val found = ConcurrentHashMap<String, Ble>()
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                found[result.device.address] = Ble(result.scanRecord?.deviceName ?: "", result.device.address, result.rssi)
            }
        }
        try {
            sc.startScan(cb)
            delay(8000)
        } catch (e: Exception) {
        } finally {
            try { sc.stopScan(cb) } catch (e: Exception) { }
        }
        return found.values.sortedByDescending { it.rssi }
    }

    suspend fun upMbps(): Double = withContext(Dispatchers.IO) {
        try {
            val size = 8_000_000
            val c = URL("https://speed.cloudflare.com/__up").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true
            c.setFixedLengthStreamingMode(size)
            c.connectTimeout = 5000; c.readTimeout = 15000
            val buf = ByteArray(65536)
            val s = System.nanoTime()
            c.outputStream.use { o ->
                var sent = 0
                while (sent < size) {
                    val n = minOf(buf.size, size - sent)
                    o.write(buf, 0, n)
                    sent += n
                }
            }
            c.responseCode
            size * 8 / 1e6 / ((System.nanoTime() - s) / 1e9)
        } catch (e: Exception) { -1.0 }
    }

    suspend fun publicIp(): String = withContext(Dispatchers.IO) {
        try {
            val j = JSONObject(URL("https://ipinfo.io/json").readText())
            "${j.optString("ip")} · ${j.optString("org")} · ${j.optString("city")}, ${j.optString("country")}"
        } catch (e: Exception) { "—" }
    }
}
