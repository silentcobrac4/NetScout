package com.amir.netscout

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Meta(
    var nick: String = "", var note: String = "", var trusted: Boolean = false,
    var first: Long = 0, var last: Long = 0, var mac: String = "", var alerted: Boolean = false
)

data class SpeedRec(val t: Long, val down: Double, val up: Double, val ping: Long)

object Store {
    var mode by mutableIntStateOf(0)
    var accent by mutableIntStateOf(0)
    var monitorMin by mutableIntStateOf(0)
    var tick by mutableIntStateOf(0)
    private lateinit var sp: SharedPreferences
    val meta = linkedMapOf<String, Meta>()
    val speeds = mutableListOf<SpeedRec>()

    fun init(ctx: Context) {
        if (::sp.isInitialized) return
        sp = ctx.applicationContext.getSharedPreferences("netscout", Context.MODE_PRIVATE)
        mode = sp.getInt("mode", 0); accent = sp.getInt("accent", 0); monitorMin = sp.getInt("mon", 0)
        try {
            val o = JSONObject(sp.getString("meta", "{}") ?: "{}")
            for (k in o.keys()) {
                val m = o.getJSONObject(k)
                meta[k] = Meta(m.optString("n"), m.optString("o"), m.optBoolean("t"), m.optLong("f"),
                    m.optLong("l"), m.optString("m"), m.optBoolean("a"))
            }
            val a = JSONArray(sp.getString("speeds", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val s = a.getJSONObject(i)
                speeds.add(SpeedRec(s.getLong("t"), s.getDouble("d"), s.getDouble("u"), s.getLong("p")))
            }
        } catch (e: Exception) { }
    }

    fun save() {
        val o = JSONObject()
        for ((k, m) in meta) {
            o.put(k, JSONObject().put("n", m.nick).put("o", m.note).put("t", m.trusted)
                .put("f", m.first).put("l", m.last).put("m", m.mac).put("a", m.alerted))
        }
        val a = JSONArray()
        for (s in speeds) a.put(JSONObject().put("t", s.t).put("d", s.down).put("u", s.up).put("p", s.ping))
        sp.edit().putString("meta", o.toString()).putString("speeds", a.toString())
            .putInt("mode", mode).putInt("accent", accent).putInt("mon", monitorMin).apply()
    }

    fun touch() { save(); tick++ }

    fun key(d: Device): String = d.mac.ifEmpty { d.ip }
    fun metaFor(d: Device): Meta = meta.getOrPut(key(d)) { Meta(first = System.currentTimeMillis()) }
    fun baseline(): Boolean = meta.values.any { it.trusted }

    fun trustAll(ds: List<Device>) {
        for (d in ds) metaFor(d).trusted = true
        touch()
    }

    /** Records sightings. Returns unknown devices not yet alerted (only once a baseline exists). */
    fun record(ds: List<Device>): List<Device> {
        val now = System.currentTimeMillis()
        val base = baseline()
        val fresh = mutableListOf<Device>()
        for (d in ds) {
            val m = metaFor(d)
            if (m.first == 0L) m.first = now
            m.last = now
            if (d.mac.isNotEmpty() && m.mac.isEmpty()) m.mac = d.mac
            if (base && !m.trusted && !m.alerted && !d.isSelf && !d.isGateway) {
                m.alerted = true
                fresh.add(d)
            }
        }
        save()
        return fresh
    }

    fun addSpeed(r: SpeedRec) {
        speeds.add(r)
        while (speeds.size > 60) speeds.removeAt(0)
        touch()
    }

    // ---- export ----
    private fun fmt(t: Long) = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(t))

    private fun name(d: Device): String = (meta[key(d)]?.nick ?: "").ifBlank { d.host }

    fun csv(ds: List<Device>): String {
        fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
        val sb = StringBuilder("ip,name,mac,type,ping_ms,known,first_seen,last_seen\n")
        for (d in ds.sortedBy { Net.ipToLong(it.ip) }) {
            val m = meta[key(d)]
            sb.append(listOf(q(d.ip), q(name(d)), q(d.mac), q(d.kind), d.pingMs.toString(),
                (m?.trusted == true).toString(), q(fmt(m?.first ?: 0)), q(fmt(m?.last ?: 0))).joinToString(",")).append("\n")
        }
        sb.append("\ntime,download_mbps,upload_mbps,ping_ms\n")
        for (s in speeds) sb.append("${fmt(s.t)},%.1f,%.1f,${s.ping}\n".format(s.down, s.up))
        return sb.toString()
    }

    fun lines(ds: List<Device>): List<String> {
        val out = mutableListOf("NetScout report - " + fmt(System.currentTimeMillis()), "", "Devices (${ds.size})")
        for (d in ds.sortedBy { Net.ipToLong(it.ip) }) {
            val m = meta[key(d)]
            out.add(d.ip.padEnd(16) + name(d).take(24).padEnd(26) + d.mac.padEnd(19) + d.kind + (if (m?.trusted == true) "  known" else ""))
        }
        out.add(""); out.add("Speed history")
        for (s in speeds.takeLast(30)) out.add(fmt(s.t) + "  down %.1f  up %.1f Mbps  ping %d ms".format(s.down, s.up, s.ping))
        return out
    }

    fun csvFile(ctx: Context, ds: List<Device>): File =
        File(ctx.cacheDir, "netscout-report.csv").also { it.writeText(csv(ds)) }

    fun pdfFile(ctx: Context, ds: List<Device>): File {
        val doc = PdfDocument()
        val paint = Paint().apply { textSize = 10f }
        lines(ds).chunked(52).forEachIndexed { i, chunk ->
            val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, i + 1).create())
            chunk.forEachIndexed { j, l -> page.canvas.drawText(l.take(100), 36f, 50f + j * 15f, paint) }
            doc.finishPage(page)
        }
        val f = File(ctx.cacheDir, "netscout-report.pdf")
        f.outputStream().use { doc.writeTo(it) }
        doc.close()
        return f
    }

    fun share(ctx: Context, f: File, mime: String) {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
