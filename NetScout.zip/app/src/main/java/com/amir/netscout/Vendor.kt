package com.amir.netscout

import android.content.Context

/** MAC vendor lookup from the bundled IEEE OUI list (assets/oui.txt, "AABBCC<TAB>Vendor"). */
object Vendor {
    private var map: HashMap<String, String>? = null

    @Synchronized
    private fun load(ctx: Context): HashMap<String, String> {
        map?.let { return it }
        val m = HashMap<String, String>(40000)
        try {
            ctx.applicationContext.assets.open("oui.txt").bufferedReader().useLines { ls ->
                for (l in ls) {
                    if (l.length > 7 && l[6] == '\t') m[l.substring(0, 6)] = l.substring(7).trim()
                }
            }
        } catch (e: Exception) { }
        map = m
        return m
    }

    /** Phones rotate random "private" MACs (locally administered bit). They have no vendor. */
    fun isPrivate(mac: String): Boolean {
        val first = mac.filter { it.isLetterOrDigit() }.take(2).toIntOrNull(16) ?: return false
        return (first and 2) != 0
    }

    fun lookup(ctx: Context, mac: String): String {
        val hex = mac.filter { it.isLetterOrDigit() }.uppercase()
        if (hex.length < 6) return ""
        if (isPrivate(hex)) return t("Private (random) address", "عنوان عشوائي (خاص)")
        return load(ctx)[hex.substring(0, 6)] ?: ""
    }

    fun describe(ctx: Context, mac: String): String {
        val hex = mac.filter { it.isLetterOrDigit() }
        if (hex.length < 6) return "Enter a MAC address like AA:BB:CC:DD:EE:FF"
        val v = lookup(ctx, mac)
        return "MAC: $mac\nVendor: " + v.ifEmpty { "not found in the database" } +
            (if (isPrivate(hex)) "\nThis is a randomized address, so the vendor cannot be known." else "")
    }
}
