package com.amir.netscout

import android.content.Context
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.CompletableFuture
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.TimeUnit

class Incoming(val from: String, val name: String, val size: Long) {
    val decision = CompletableFuture<Boolean>()
}

/** Simple LAN file sharing between NetScout devices. Receiver must accept every file. */
object Share {
    const val PORT = 45454
    const val DISC = 45455
    val peers = ConcurrentHashMap<String, String>()
    @Volatile var pending: Incoming? = null
    val received = CopyOnWriteArrayList<String>()
    @Volatile private var running = false
    private var server: ServerSocket? = null
    private var disc: DatagramSocket? = null
    private var lock: WifiManager.MulticastLock? = null

    fun inbox(ctx: Context): File = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "received").also { it.mkdirs() }

    @Synchronized
    fun start(ctx: Context, info: NetInfo?) {
        if (running || info == null) return
        running = true
        val c = ctx.applicationContext
        val myIp = info.ip
        val bcast = Net.broadcast(info)
        try {
            lock = (c.getSystemService(Context.WIFI_SERVICE) as WifiManager).createMulticastLock("ns-share").also { it.acquire() }
        } catch (e: Exception) { }
        Thread {
            try {
                DatagramSocket().use { s ->
                    s.broadcast = true
                    val msg = ("NSHELLO|" + Build.MODEL).toByteArray()
                    while (running) {
                        for (b in listOf(bcast, "255.255.255.255")) {
                            try { s.send(DatagramPacket(msg, msg.size, InetAddress.getByName(b), DISC)) } catch (e: Exception) { }
                        }
                        Thread.sleep(2000)
                    }
                }
            } catch (e: Exception) { }
        }.start()
        Thread {
            try {
                val s = DatagramSocket(null)
                s.reuseAddress = true
                s.bind(InetSocketAddress(DISC))
                disc = s
                val buf = ByteArray(512)
                while (running) {
                    val p = DatagramPacket(buf, buf.size)
                    s.receive(p)
                    val txt = String(p.data, 0, p.length)
                    val ip = p.address.hostAddress ?: continue
                    if (txt.startsWith("NSHELLO|") && ip != myIp) peers[ip] = txt.substring(8)
                }
            } catch (e: Exception) { }
        }.start()
        Thread {
            try {
                val ss = ServerSocket(PORT)
                server = ss
                while (running) {
                    val s = ss.accept()
                    Thread { handle(c, s) }.start()
                }
            } catch (e: Exception) { }
        }.start()
    }

    @Synchronized
    fun stop() {
        running = false
        try { server?.close() } catch (e: Exception) { }
        try { disc?.close() } catch (e: Exception) { }
        try { lock?.release() } catch (e: Exception) { }
        server = null
        disc = null
        lock = null
        peers.clear()
    }

    private fun handle(c: Context, s: Socket) {
        try {
            s.use { sock ->
                sock.soTimeout = 70000
                val inp = DataInputStream(BufferedInputStream(sock.getInputStream()))
                val out = DataOutputStream(BufferedOutputStream(sock.getOutputStream()))
                val name = File(inp.readUTF()).name.replace(Regex("[^\\p{L}\\p{N}._ -]"), "_")
                    .take(120).trim('.').ifBlank { "file" }
                val size = inp.readLong()
                if (pending != null || size < 0) { out.writeBoolean(false); out.flush(); return }
                val inc = Incoming(sock.inetAddress.hostAddress ?: "?", name, size)
                pending = inc
                val ok = try { inc.decision.get(60, TimeUnit.SECONDS) } catch (e: Exception) { false }
                pending = null
                out.writeBoolean(ok)
                out.flush()
                if (!ok) return
                var f = File(inbox(c), name)
                var n = 1
                while (f.exists()) { f = File(inbox(c), (n++).toString() + "_" + name) }
                f.outputStream().use { fo ->
                    val buf = ByteArray(65536)
                    var left = size
                    while (left > 0) {
                        val r = inp.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                        if (r < 0) throw EOFException()
                        fo.write(buf, 0, r)
                        left -= r
                    }
                }
                received.add(0, f.absolutePath)
                out.writeBoolean(true)
                out.flush()
            }
        } catch (e: Exception) { pending = null }
    }

    suspend fun send(ctx: Context, ip: String, uri: Uri, onProgress: (Float) -> Unit): String = withContext(Dispatchers.IO) {
        val cr = ctx.contentResolver
        var name = "file"
        var size = -1L
        cr.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = c.getString(ni) ?: name
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
            }
        }
        var src: InputStream = cr.openInputStream(uri) ?: throw IOException("Cannot open file")
        if (size < 0) {
            val tmp = File(ctx.cacheDir, "send.tmp")
            src.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            size = tmp.length()
            src = tmp.inputStream()
        }
        val total = size
        src.use { input ->
            Socket().use { s ->
                s.connect(InetSocketAddress(ip, PORT), 4000)
                s.soTimeout = 70000
                val out = DataOutputStream(BufferedOutputStream(s.getOutputStream()))
                val inp = DataInputStream(BufferedInputStream(s.getInputStream()))
                out.writeUTF(name)
                out.writeLong(total)
                out.flush()
                if (!inp.readBoolean()) throw IOException("Receiver declined or is busy")
                val buf = ByteArray(65536)
                var sent = 0L
                while (true) {
                    val r = input.read(buf)
                    if (r < 0) break
                    out.write(buf, 0, r)
                    sent += r
                    onProgress(if (total > 0) sent.toFloat() / total else 1f)
                }
                out.flush()
                if (!inp.readBoolean()) throw IOException("Transfer failed")
            }
        }
        name
    }
}
