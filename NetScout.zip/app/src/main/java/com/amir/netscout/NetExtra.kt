package com.amir.netscout

import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.json.JSONObject
import java.net.*

data class Ap(val ssid: String, val bssid: String, val level: Int, val freq: Int, val caps: String)

object NetX {
    private fun exec(args: List<String>): String = try {
        val p = ProcessBuilder(args).redirectErrorStream(true).start()
        val s = p.inputStream.bufferedReader().readText()
        p.waitFor()
        s
    } catch (e: Exception) { "" }

    suspend fun streamCmd(args: List<String>, onLine: (String) -> Unit) = withContext(Dispatchers.IO) {
        try {
            val p = ProcessBuilder(args).redirectErrorStream(true).start()
            p.inputStream.bufferedReader().use { r ->
                while (true) {
                    val l = r.readLine() ?: break
                    withContext(Dispatchers.Main) { onLine(l) }
                }
            }
            p.waitFor()
        } catch (e: Exception) {
            withContext(Dispatchers.Main) { onLine("error: ${e.message}") }
        }
    }

    suspend fun traceroute(host: String, maxHops: Int = 20, onHop: (Int, String, Long) -> Unit) =
        withContext(Dispatchers.IO) {
            val ipRe = Regex("from (\\d+\\.\\d+\\.\\d+\\.\\d+)", RegexOption.IGNORE_CASE)
            for (ttl in 1..maxHops) {
                val t = System.nanoTime()
                val out = exec(listOf("/system/bin/ping", "-c", "1", "-t", "$ttl", "-W", "2", host))
                val ms = (System.nanoTime() - t) / 1_000_000
                val ip = ipRe.find(out)?.groupValues?.get(1) ?: "*"
                withContext(Dispatchers.Main) { onHop(ttl, ip, ms) }
                if (out.contains("bytes from") && !out.contains("exceeded")) break
            }
        }

    suspend fun ssdp(): Map<String, String> = withContext(Dispatchers.IO) {
        val res = mutableMapOf<String, String>()
        try {
            DatagramSocket().use { s ->
                s.soTimeout = 1000
                val msg = ("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\n" +
                    "MAN: \"ssdp:discover\"\r\nMX: 1\r\nST: ssdp:all\r\n\r\n").toByteArray()
                s.send(DatagramPacket(msg, msg.size, InetAddress.getByName("239.255.255.250"), 1900))
                val buf = ByteArray(2048)
                val end = System.currentTimeMillis() + 2500
                while (System.currentTimeMillis() < end) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        s.receive(p)
                        val txt = String(p.data, 0, p.length)
                        val server = Regex("(?im)^server:\\s*(.+)$").find(txt)?.groupValues?.get(1)?.trim() ?: "UPnP"
                        res[p.address.hostAddress ?: ""] = server
                    } catch (e: SocketTimeoutException) { }
                }
            }
        } catch (e: Exception) { }
        res
    }

    fun netbios(ip: String): String = try {
        val q = ByteArray(50)
        q[0] = 0x13; q[1] = 0x37; q[5] = 1; q[12] = 0x20
        q[13] = 'C'.code.toByte(); q[14] = 'K'.code.toByte()
        for (i in 15..44) q[i] = 'A'.code.toByte()
        q[47] = 0x21; q[49] = 1
        DatagramSocket().use { s ->
            s.soTimeout = 600
            s.send(DatagramPacket(q, q.size, InetAddress.getByName(ip), 137))
            val buf = ByteArray(512)
            val p = DatagramPacket(buf, buf.size)
            s.receive(p)
            if (p.length > 72) String(buf, 57, 15).trim() else ""
        }
    } catch (e: Exception) { "" }

    fun broadcastOf(i: NetInfo): String {
        val prefix = maxOf(i.prefix, 24)
        val mask = (0xFFFFFFFFL shl (32 - prefix)) and 0xFFFFFFFFL
        return Net.longToIp((Net.ipToLong(i.ip) and mask) or (mask.inv() and 0xFFFFFFFFL))
    }

    suspend fun wol(mac: String, broadcast: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val b = mac.trim().split(":", "-").map { it.toInt(16).toByte() }
            require(b.size == 6)
            val pk = ByteArray(6) { 0xFF.toByte() } + (1..16).flatMap { b }.toByteArray()
            DatagramSocket().use {
                it.broadcast = true
                it.send(DatagramPacket(pk, pk.size, InetAddress.getByName(broadcast), 9))
            }
            true
        } catch (e: Exception) { false }
    }

    suspend fun scanRange(ip: String, from: Int, to: Int): List<Int> = coroutineScope {
        val sem = Semaphore(150)
        (from..to).map { p ->
            async(Dispatchers.IO) {
                sem.withPermit {
                    try { Socket().use { it.connect(InetSocketAddress(ip, p), 300) }; p } catch (e: Exception) { null }
                }
            }
        }.awaitAll().filterNotNull()
    }

    private fun getText(url: String, accept: String? = null): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 5000; c.readTimeout = 6000
        if (accept != null) c.setRequestProperty("accept", accept)
        return c.inputStream.bufferedReader().readText()
    }

    suspend fun dnsQuery(name: String, type: String): List<String> = withContext(Dispatchers.IO) {
        try {
            val j = JSONObject(getText(
                "https://cloudflare-dns.com/dns-query?name=${URLEncoder.encode(name, "UTF-8")}&type=$type",
                "application/dns-json"))
            val a = j.optJSONArray("Answer")
            if (a == null) emptyList() else List(a.length()) { a.getJSONObject(it).getString("data") }
        } catch (e: Exception) { listOf("error: ${e.message}") }
    }

    suspend fun httpCheck(url: String): String = withContext(Dispatchers.IO) {
        try {
            val u = if (url.startsWith("http")) url else "https://$url"
            val c = URL(u).openConnection() as HttpURLConnection
            c.requestMethod = "HEAD"; c.connectTimeout = 5000; c.readTimeout = 5000
            val s = System.nanoTime()
            val code = c.responseCode
            "HTTP $code · ${(System.nanoTime() - s) / 1_000_000} ms"
        } catch (e: Exception) { "error: ${e.message}" }
    }

    suspend fun macVendor(mac: String): String = withContext(Dispatchers.IO) {
        try { getText("https://api.macvendors.com/" + URLEncoder.encode(mac.trim(), "UTF-8")) }
        catch (e: Exception) { "—" }
    }

    suspend fun publicInfo(): List<Pair<String, String>> = withContext(Dispatchers.IO) {
        try {
            val j = JSONObject(getText("https://ipwho.is/"))
            val c = j.optJSONObject("connection")
            listOf(
                "IP" to j.optString("ip"), "ISP" to (c?.optString("isp") ?: ""),
                "ASN" to (c?.optString("asn") ?: ""),
                "Country" to j.optString("country"), "City" to j.optString("city")
            )
        } catch (e: Exception) { listOf("error" to (e.message ?: "")) }
    }

    suspend fun uploadMbps(): Double = withContext(Dispatchers.IO) {
        try {
            val size = 8_000_000
            val c = URL("https://speed.cloudflare.com/__up").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true
            c.setFixedLengthStreamingMode(size)
            c.connectTimeout = 5000; c.readTimeout = 10000
            val s = System.nanoTime()
            c.outputStream.use { o ->
                val b = ByteArray(65536)
                var left = size
                while (left > 0) { val n = minOf(left, b.size); o.write(b, 0, n); left -= n }
            }
            c.responseCode
            size * 8 / 1e6 / ((System.nanoTime() - s) / 1e9)
        } catch (e: Exception) { -1.0 }
    }

    @Suppress("DEPRECATION")
    suspend fun wifiScan(ctx: Context): List<Ap> {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        try { wm.startScan() } catch (e: Exception) { }
        delay(2500)
        return try {
            wm.scanResults.map { Ap(it.SSID ?: "", it.BSSID ?: "", it.level, it.frequency, it.capabilities ?: "") }
                .sortedByDescending { it.level }
        } catch (e: SecurityException) { emptyList() }
    }

    fun channel(f: Int): Int = when {
        f == 2484 -> 14
        f < 2484 -> (f - 2407) / 5
        f in 5000..5900 -> (f - 5000) / 5
        f >= 5955 -> (f - 5950) / 5
        else -> 0
    }

    fun secLabel(caps: String): String = when {
        caps.contains("WPA3") || caps.contains("SAE") -> "WPA3"
        caps.contains("WPA2") -> "WPA2"
        caps.contains("WPA") -> "WPA (weak)"
        caps.contains("WEP") -> "WEP (insecure)"
        else -> "Open"
    }
}
