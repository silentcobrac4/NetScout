# NetScout
Free, open-source, ad-free Wi-Fi network toolkit for Android (Kotlin + Jetpack Compose). Arabic/English, RTL.

Devices: discovery (ping sweep, reverse DNS, mDNS, NetBIOS, SSDP/UPnP), type guess, nicknames/notes, known/unknown, intruder alerts, first/last seen.
Tools: Ping, Traceroute, DNS (A/AAAA/MX/TXT/NS), WHOIS, port scanner, Wake-on-LAN, HTTP check, router security check, BLE scanner, password generator.
Wi-Fi analyzer, internet speed test (down/up/latency/public IP) with history chart, CSV/PDF export, themes.
Uses public endpoints: Cloudflare (speed test, DNS-over-HTTPS) and ipinfo.io (public IP).
License: MIT
